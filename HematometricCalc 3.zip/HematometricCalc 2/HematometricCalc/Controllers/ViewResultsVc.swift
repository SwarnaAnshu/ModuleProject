//
//  ViewResultsVc.swift
//  HematometricCalc
//
//  Created by SAIL on 14/03/24.
//

import UIKit

class ViewResultsVc: UIViewController ,UITextFieldDelegate {
    @IBOutlet var dateTxt : UITextField!
    @IBOutlet var categoryField: UITextField!
    @IBOutlet var subcategoryField: UITextField!
    
    @IBOutlet weak var backbtn: UIButton!
    @IBOutlet var subcategoryView: UIView!
    @IBOutlet var resultCountLabel: UILabel!

    @IBOutlet weak var resultView: UIView!
    @IBOutlet weak var resultTable: UITableView! {
        didSet {
            resultTable.delegate = self
            resultTable.dataSource = self
            resultTable.register(UINib.init(nibName: "ResultTableViewCell", bundle: nil), forCellReuseIdentifier: "ResultTableViewCell")
        }
    }
    var resultList: [String] = []
       var request = ViewResultRequest()
         var selectedDate = ""
         var selectedCategory = ""
         var selectedSubCategory = ""
       var selectedCategoryID = ""
       var selectedSubCategoryID = ""
         var datePicker = UIDatePicker()
       var categoryList : [Category] = []
       var subcategoryList : [SubCategory] = []
       let categorySubcategories : [String: [String]] = [
           "RBC Indices":["MCV","MCH","MCHC"],"Reticulocyte":["Reticulocyte Count","Absolute Reticulocyte Count","Corrected Reticulocyte Count using PCV","Corrected Reticulocyte Count using Hb","Reticulocyte Production Index"],"WBC Count":[],"Corrected WBC": [],"Platelet Count":[]]
       
         override func viewDidLoad() {
             super.viewDidLoad()
             resultView.isHidden = true
             dateTxt.delegate = self
             categoryField.delegate = self
             subcategoryField.delegate = self
             getCategoryAPI()
             print("Category List :\(categoryList)")
             subcategoryView.isHidden = false
             //backbtn.setTitle("", for: .normal)
         }
       func textFieldDidBeginEditing(_ textField: UITextField) {
           if textField == dateTxt {
               setupDatePicker()
           }
           else if textField == categoryField {
               setupCategoryPicker()
               //showPickerView(for: categoryField, dataSource: )
           }
           else if textField == subcategoryField {
               guard let selectedCategory = categoryField.text,!selectedCategory.isEmpty else {
                   return
               }
               let subcategories = categorySubcategories[selectedCategory] ?? []
               showPickerView(for: subcategoryField, dataSource: subcategories)
               setupSubcategoryPicker()
           }
       }
       func setupDatePicker() {
               // Format Date
               datePicker.datePickerMode = .date
               if #available(iOS 13.4, *) {
                   if #available(iOS 14.0, *) {
                       datePicker.preferredDatePickerStyle = .inline
                   } else {
                       // Fallback on earlier versions
                   }
               } else {
                   if #available(iOS 13.4, *) {
                       datePicker.preferredDatePickerStyle = .wheels
                   } else {
                       // Fallback on earlier versions
                   }
               }
               let toolbar = UIToolbar()
               toolbar.sizeToFit()
               // Done button & cancel button
               let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(donedatePicker))
               let spaceButton = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
               let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelDatePicker))
               
               toolbar.setItems([cancelButton, spaceButton, doneButton], animated: false)
           dateTxt.inputAccessoryView = toolbar
           dateTxt.inputView = datePicker
       }
       func setupCategoryPicker() {
           let pickerView = UIPickerView()
           pickerView.delegate = self
           pickerView.dataSource = self
           let toolbar = UIToolbar()
           toolbar.sizeToFit()
           let doneBtn = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(categoryPickerDoneButtonTapped))
           let spaceBtn = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
           let cancelBtn = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelPicker))
               toolbar.setItems([cancelBtn, spaceBtn, doneBtn], animated: false)
               categoryField.inputView = pickerView
               categoryField.inputAccessoryView = toolbar
       }
       func setupSubcategoryPicker() {
           let pickerView = UIPickerView()
           pickerView.delegate = self
           pickerView.dataSource = self
           let toolbar = UIToolbar()
           toolbar.sizeToFit()
           let doneBtn = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(subcategoryPickerDoneButtonTapped))
           let spaceBtn = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
           let cancelBtn = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelPicker))
           toolbar.setItems([cancelBtn, spaceBtn, doneBtn], animated: false)
           subcategoryField.inputView = pickerView
           subcategoryField.inputAccessoryView = toolbar
       }
       @objc func categoryPickerDoneButtonTapped() {
           categoryField.resignFirstResponder()
       }

       @objc func subcategoryPickerDoneButtonTapped() {
           subcategoryField.resignFirstResponder()
       }
       @objc func cancelPicker() {
           categoryField.resignFirstResponder()
           subcategoryField.resignFirstResponder()
       }
       func showPickerView(for textField : UITextField, dataSource : [String]) {
           let pickerView = UIPickerView()
           pickerView.delegate = self
           pickerView.dataSource = self
           textField.inputView = pickerView
           pickerView.reloadAllComponents()
       }
       @objc func cancelDatePicker() {
           dateTxt.endEditing(true)
       }
       @objc func donedatePicker() {
           let formatter = DateFormatter()
           formatter.dateFormat = "yyyy-MM-dd"
           dateTxt.text = formatter.string(from: datePicker.date)
           selectedDate = dateTxt.text!
           view.endEditing(true)
       }
    @IBAction func onGenerate(_ sender: Any) {
        resultView.isHidden = false
        ViewResultAPI(request: ViewResultRequest(date: selectedDate, categoryID: selectedCategoryID, subcategoryID: selectedSubCategoryID))
    }
    
    @IBAction func onback(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
       
   }
   extension ViewResultsVc{
       func getCategoryAPI() {
           APIHandler().getAPIValues(type: getCategoryResponse.self, apiUrl: ServiceAPI.getCategory, method: "GET") { result in
               switch result {
               case .success(let response):
                  // LoadingIndicator.shared.hideLoading()
                   DispatchQueue.main.async {
   //                    LoadingIndicator.shared.hideLoading()
                       self.categoryList = response.data
                   }
               case .failure(let error):
                   print(error)
               }
           }
       }
       func getSubCategoryAPI() {
           let formData : [String: Any] = ["catid" : selectedCategoryID]
           APIHandler().postAPIValues(type: getSubCategoryResponse.self, apiUrl: ServiceAPI.getSubCategory, method: "POST", formData: formData) { result in
               switch result {
               case .success(let response):
                   if response.status == "success" {
                       DispatchQueue.main.async {
                           self.subcategoryList = response.data
                           self.subcategoryView.isHidden = false
                       }
                   }
                   else {
                       self.subcategoryView.isHidden = true
                       
                       print("No Subcategories available : \(response.message)")
                   }
                  
               case .failure(let error):
                   print(error)
               }
           }
       }
       func ViewResultAPI(request : ViewResultRequest) {
           let formData : [String: Any] = [
               "date": selectedDate,
               "catid":selectedCategoryID,
               "subid":selectedSubCategoryID
           ]
           APIHandler().postAPIValues(type: ViewResultResponse.self, apiUrl: ServiceAPI.viewResult, method: "POST", formData: formData) { result in
               switch result {
               case .success(let response):
                   DispatchQueue.main.async { [self] in
                       self.resultList = response.data
                       if resultList.count == 0{
                           AlertManager.showAlert(title: "Alert", message: "No Data Found", viewController: self, completionHandler: {})
                       }
                       resultCountLabel.text = "\(resultList.count)"
                       resultTable.reloadData()
                       print("Status: \(response.status)")
                   }
               case .failure(let error):
                   print("Error : \(error)")
               }
           }
       }
   }
   extension ViewResultsVc : UITableViewDelegate, UITableViewDataSource {
       func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            resultList.count
       }
       
       func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
           let cell = tableView.dequeueReusableCell(withIdentifier: "ResultTableViewCell", for: indexPath) as! ResultTableViewCell
           cell.resultLbl.text = resultList[indexPath.row]
           return cell
       }
       func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
           40
       }
   }
   extension ViewResultsVc : UIPickerViewDelegate,UIPickerViewDataSource {
       func numberOfComponents(in pickerView: UIPickerView) -> Int {
           return 1
       }
       
       func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
           if pickerView == categoryField.inputView as? UIPickerView {
               return categoryList.count
           }
           else if pickerView == subcategoryField.inputView as? UIPickerView {
               return subcategoryList.count
           }
           return 0
       }
       func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
               if pickerView == categoryField.inputView as? UIPickerView {
                   return categoryList[row].catName
               } else if pickerView == subcategoryField.inputView as? UIPickerView {
                   return subcategoryList[row].subName
               }
               return nil
           }
           
           func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
               if pickerView == categoryField.inputView as? UIPickerView {
                   let selectedCategory = categoryList[row]
                   categoryField.text = selectedCategory.catName
                   selectedCategoryID = selectedCategory.catId
                   subcategoryField.text = ""
                   selectedSubCategoryID = ""
                   getSubCategoryAPI()
               }
               else if pickerView == subcategoryField.inputView as? UIPickerView {
                   let selectedSubCategory = subcategoryList[row]
                   subcategoryField.text = selectedSubCategory.subName
                   selectedSubCategoryID = selectedSubCategory.subId
                   
               }
               if let textField = pickerView.superview as? UITextField {
                   textField.resignFirstResponder()
               }
               if subcategoryList.isEmpty {
                   subcategoryView.isHidden = true
               }
               else {
                   subcategoryView.isHidden = false
               }
           }
   }

