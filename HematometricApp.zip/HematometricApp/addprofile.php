<?php

// Assuming you have already established a database connection

// Retrieving data from request
$conn1=mysqli_connect("localhost","root","","calci1");
if($conn1->connect_error){
    die("Connection failed ".$conn1->connect_error);
}

$name = $_POST['name']; // Assuming you're receiving date via POST method
$phno = $_POST['phno']; // Assuming you're receiving subid via POST method
$pass = $_POST['pass'];
$gender=$_POST['gender'];
// Assuming you're receiving resultval via POST method

// Inserting data into the database
$query = "INSERT INTO docdetails VALUES ('$name', '$phno', '$pass','$gender')";
$result = mysqli_query($conn1, $query); // Assuming $connection is your database connection object

$response = array();

if ($result) {
    $response['success'] = true;
    $response['message'] = "Data inserted successfully";
} else {
    $response['success'] = false;
    $response['message'] = "Error inserting data: " . mysqli_error($conn1);
}

// Sending response in JSON format
header('Content-Type: application/json');
echo json_encode($response);

?>