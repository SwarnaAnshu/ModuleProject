//
//  calculationRequest.swift
//  HematometricCalc
//
//  Created by Saranya Ravi on 13/02/24.
//

import Foundation
struct CalculationRequest : Codable {
    var currentDate : String
    var categoryId : Int
    var subcategoryId : String
    var result : String
    enum CodingKeys: String,CodingKey {
        case currentDate = "date"
        case categoryId = "catid"
        case subcategoryId = "subid"
        case result = "resultval"
    }
}

