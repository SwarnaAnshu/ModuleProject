//
//  MainMenuVc.swift
//  HematometricCalc
//
//  Created by SAIL on 29/01/24.
//

import UIKit

class MainMenuVc: UIViewController,SideMenu {
   
    
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    
    func tap(index: Int) {
        switch index {
        case 1:
            let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewResultsVc") as! ViewResultsVc;            self.navigationController?.pushViewController(vc, animated: true)
        case 2:
            let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AboutUsVc") as! AboutUsVc
            self.navigationController?.pushViewController(vc, animated: true)
        case 3:
            let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DoctorLoginVc") as! DoctorLoginVc
            self.navigationController?.pushViewController(vc, animated: true)
        default:
            print("")
        }
    }
    
    
    
    
    @IBAction func sideMenuTap(_ sender: Any) {
        
        
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SideMenuViewController") as! SideMenuViewController
        vc.delegate = self
        vc.modalPresentationStyle = .overFullScreen
        self.navigationController?.present(vc, animated: false, completion: nil)
        
    }
    
    
    
    
    
    
    @IBAction func onRBC(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "RBCVc") as! RBCVc
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func onReticulocyte(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ReticulocyteVC") as! ReticulocyteVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func onWBC(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "WBCCountVC") as! WBCCountVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func onCorrelatedWBC(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CorrectedWBCVC") as! CorrectedWBCVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func onPlatelet(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "PlateletCountVC") as! PlateletCountVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func sideMenu(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "logoutVc") as!
        logoutVc
        vc.modalPresentationStyle = .overCurrentContext
        navigationController?.present(vc, animated: true, completion: nil)
    }
    @IBAction func onProfile(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewProfileVc") as! ViewProfileVc
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
