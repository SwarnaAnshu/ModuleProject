<?php
// Establishing a database connection
$conn = mysqli_connect("localhost", "root", "", "calci1");

// Checking the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieving data from request
$name = isset($_POST['name']) ? $_POST['name'] : '';
$pass = isset($_POST['password']) ? $_POST['password'] : '';
$confirm_pass = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';

// Validating data
if (empty($name) || empty($pass) || empty($confirm_pass)) {
    $response = array(
        'success' => false,
        'message' => 'Name, password, and confirm password are required'
    );
} elseif ($pass !== $confirm_pass) {
    $response = array(
        'success' => false,
        'message' => 'Passwords do not match'
    );
} else {
    // Check if the record already exists in the signup table
    $check_query = "SELECT * FROM signup WHERE name='$name'";
    $check_result = mysqli_query($conn, $check_query);
    $num_rows = mysqli_num_rows($check_result);

    if ($num_rows > 0) {
        // If record exists, update it
        $update_query_signup = "UPDATE signup SET password='$pass', confirm_password='$confirm_pass' WHERE name='$name'";
        $update_result_signup = mysqli_query($conn, $update_query_signup);

        // Update the forgot_password table
        $update_query_forgot = "UPDATE forgot_password SET new_password='$pass', confirm_password='$confirm_pass' WHERE name='$name'";
        $update_result_forgot = mysqli_query($conn, $update_query_forgot);

        // Update the docdetails table
        $update_query_docdetails = "UPDATE docdetails SET pass='$pass' WHERE name='$name'";
        $update_result_docdetails = mysqli_query($conn, $update_query_docdetails);

        if ($update_result_signup && $update_result_forgot && $update_result_docdetails) {
            $response = array(
                'success' => true,
                'message' => 'Password updated successfully for the user: ' . $name
            );
        } else {
            $response = array(
                'success' => false,
                'message' => 'Error updating password: ' . mysqli_error($conn)
            );
        }
    } else {
        // If record does not exist, return error
        $response = array(
            'success' => false,
            'message' => 'User with name: ' . $name . ' does not exist'
        );
    }
}

// Sending response in JSON format
header('Content-Type: application/json');
echo json_encode($response);

// Closing the database connection
mysqli_close($conn);
?>
