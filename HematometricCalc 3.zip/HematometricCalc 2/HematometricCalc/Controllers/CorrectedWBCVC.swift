import UIKit

class CorrectedWBCVC: UIViewController, UITextViewDelegate {
    
    @IBOutlet weak var topView: UIView! {
        didSet {
            topView.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        }
    }
    
    
    @IBOutlet weak var wbcTxt: UITextView!
    @IBOutlet weak var nucleatedRbcTxt: UITextView!
    @IBOutlet weak var resultLbl: UILabel!
    @IBOutlet weak var saveBtn: UIButton!
    
    @IBOutlet weak var backbtn: UIButton!
    var patientId = UserDefaultsManager.shared.getPatientId() ?? ""
    var CorrectedWBCResult = String()
    let saveresult = SaveResult()
    var wbcPlaceholder = "WBC Count * 100"
    var nucleatedrbcPlaceholder = "Nucleated RBCs per 100 WBC + 100"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.wbcTxt.delegate = self
        self.nucleatedRbcTxt.delegate = self
        wbcTxt.text = wbcPlaceholder
        nucleatedRbcTxt.text = nucleatedrbcPlaceholder
        wbcTxt.textColor = .lightGray
        nucleatedRbcTxt.textColor = .lightGray
        saveBtn.isHidden = true
        resultLbl.isHidden = true
        backbtn.setTitle("", for: .normal)

    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView == wbcTxt && textView.text == wbcPlaceholder {
            textView.text = ""
            textView.textColor = .black
        } else if textView == nucleatedRbcTxt && textView.text == nucleatedrbcPlaceholder {
            textView.text = ""
            textView.textColor = .black
        }
    }
    
    @IBAction func onCalculate(_ sender: Any) {
        guard let wbcText = wbcTxt.text, !wbcText.isEmpty,
              let nucleatedRbcText = nucleatedRbcTxt.text, !nucleatedRbcText.isEmpty else {
            showAlert(message: "Please enter values in all fields")
            return
        }
        
        calculateCorrectedWBCCount()
        saveBtn.isHidden = false
        resultLbl.isHidden = false
    }
    
    @IBAction func onSave(_ sender: Any) {
        guard let wbcText = wbcTxt.text, !wbcText.isEmpty,
              let nucleatedRbcText = nucleatedRbcTxt.text, !nucleatedRbcText.isEmpty else {
            showAlert(message: "Please enter values in all fields")
            return
        }
        
        calculateCorrectedWBCCount()
        SaveCorrectedWBCAPI()
    }
    
    func calculateCorrectedWBCCount() {
        if let text1 = wbcTxt.text, let text2 = nucleatedRbcTxt.text,
            let value1 = Double(text1), let value2 = Double(text2) {
            let Result = (value1 * 100) / (value2 + 100)
            self.CorrectedWBCResult = String(format: "%.2f", Result)
            self.resultLbl.text = "\(self.CorrectedWBCResult)"
        } else {
            print("Invalid input in text fields")
        }
    }
    
    func SaveCorrectedWBCAPI() {
        let date = DateHelper.getCurrentDateString()
        let parameterrequest = CalculationRequest(currentDate: date, categoryId: 4, subcategoryId: "4.1", result: self.resultLbl.text ?? "")
        saveresult.saveResultAPI(request: parameterrequest, viewcontroller: self) { success in
            if success {
                DispatchQueue.main.async {
                    self.wbcTxt.text = ""
                    self.nucleatedRbcTxt.text = ""
                }
            }
        }
    }
    
    @IBAction func onback(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onHistory(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewResultsVc") as! ViewResultsVc
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}
