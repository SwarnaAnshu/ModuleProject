import UIKit

class SignUpViewController: UIViewController {
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var phoneTextField: UITextField!
    @IBOutlet weak var genderTextField: UITextField!
    @IBOutlet weak var designationTextField: UITextField!
    @IBOutlet weak var confirmPasswordTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var subView: UIView!
    @IBOutlet weak var signupView: UIView!
    @IBOutlet weak var signupBtn: UIButton!
    @IBOutlet weak var genderView: UIStackView!
    let genderOptions = ["Male", "Female", "Others"]
    let mobilenumberLimit = 10
    var selectedGender = ""
    
    // Activity indicator
    let activityIndicator = UIActivityIndicatorView(style: .medium)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        genderView.isHidden = true
        
        // Configure activity indicator
        activityIndicator.center = view.center
        view.addSubview(activityIndicator)
    }
    
    @IBAction func onDropdown(_ sender: Any) {
        genderView.isHidden = false
    }
    
    @IBAction func onGender(_ sender: UIButton) {
        if sender.tag == 1 {
            selectedGender = "Male"
        } else if sender.tag == 2 {
            selectedGender = "Female"
        } else if sender.tag == 3 {
            selectedGender = "Others"
        }
        genderTextField.text = selectedGender
        genderView.isHidden = true
    }
    
    @IBAction func Signup(_ sender: Any) {
        guard isValidName() else { return }
        guard isValidPhone() else { return }
        guard isValidGender() else { return }
        guard isValidPassword() else {
            showAlert(title: "Error", message: "Please enter a valid password")
            return
        }
        guard isValidConfirmPassword() else {
            showAlert(title: "Error", message: "Passwords doesn't match")
            return
        }
        guard isValidDesignation() else {
            showAlert(title: "Error", message: "Please enter a valid Designation")
            return
        }
        signUpUser()
    }
    
    func signUpUser() {
        // Show activity indicator when signup starts
        activityIndicator.startAnimating()
        
        let formData = ["name": nameTextField.text ?? "",
                        "mobilenumber": phoneTextField.text ?? "",
                        "password": passwordTextField.text ?? "",
                        "designation": designationTextField.text ?? "",
                        "confirm_password": confirmPasswordTextField.text ?? "",
                        "gender": genderTextField.text ?? ""
        ]
        
        APIHandler().postAPIValues(type: SignupModel.self, apiUrl: ServiceAPI.signUpUrl , method: "POST", formData: formData) { [weak self] result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    // Hide activity indicator when signup finishes
                    self?.activityIndicator.stopAnimating()
                    
                    if data.status == "success" {
                        let alertController = UIAlertController(title: "Success", message: "Sign up done successfully", preferredStyle: .alert)
                        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
                            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                            let vc = storyBoard.instantiateViewController(withIdentifier: "DoctorLoginVc") as! DoctorLoginVc
                            self?.navigationController?.pushViewController(vc, animated: true)
                        }))
                        self?.present(alertController, animated: true, completion: nil)
                    } else if data.status == "error" {
                        let alertController = UIAlertController(title: "Error", message: "User already exists", preferredStyle: .alert)
                        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self?.present(alertController, animated: true, completion: nil)
                    }
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    // Hide activity indicator when signup finishes with failure
                    self?.activityIndicator.stopAnimating()
                }
            }
        }
    }
    
    @IBAction func signinpage(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "DoctorLoginVc") as! DoctorLoginVc
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func backTap(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }

    func showAlert(title: String, message: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(okAction)
        present(alertController, animated: true, completion: nil)
    }
}

extension SignUpViewController {
    func isValidName() -> Bool {
        guard let name = nameTextField.text, !name.isEmpty else {
            showAlert(title: "Error", message: "Please enter a valid name")
            return false
        }
        return true
    }
    
    func isValidPhone() -> Bool {
        guard let phone = phoneTextField.text, !phone.isEmpty else {
            showAlert(title: "Error", message: "Please enter a valid phone number")
            return false
        }
        guard phone.count == mobilenumberLimit else {
            showAlert(title: "Error", message: "Please enter a valid 10-digit phone number")
            return false
        }
        // You may add further validation for phone number format here if needed
        return true
    }
    
    func isValidGender() -> Bool {
        guard let gender = genderTextField.text, !gender.isEmpty else {
            showAlert(title: "Error", message: "Please select a gender")
            return false
        }
        return true
    }
    
    func isValidPassword() -> Bool {
        guard let password = passwordTextField.text, !password.isEmpty else {
            showAlert(title: "Error", message: "Please enter a password")
            return false
        }
        // You may add further password validation here if needed
        return true
    }
    
    func isValidConfirmPassword() -> Bool {
        guard let confirmPassword = confirmPasswordTextField.text, !confirmPassword.isEmpty else {
            showAlert(title: "Error", message: "Please confirm your password")
            return false
        }
        guard let password = passwordTextField.text, confirmPassword == password else {
            showAlert(title: "Error", message: "Passwords do not match")
            return false
        }
        return true
    }
    
    func isValidDesignation() -> Bool {
        guard let designation = designationTextField.text, !designation.isEmpty else {
            showAlert(title: "Error", message: "Please enter a designation")
            return false
        }
        // You may add further validation for designation here if needed
        return true
    }
}
