<?php
$conn1 = mysqli_connect("localhost", "root", "", "calci1");
if ($conn1->connect_error) {
    die("Connection failed " . $conn1->connect_error);
}
header("Content-Type: application/json");


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    print_r($data);

    if (isset($_POST["name"]) && isset($_POST["pass"])) {
        require_once "validate.php";
        $name = validate($_POST["name"]);
        $password = validate($_POST["pass"]);
        $sql = "SELECT * FROM docdetails WHERE name = '$name' AND pass = '$password'";
        $result = $conn1->query($sql);

        if ($result->num_rows > 0) {
            $response = array('status' => 'success', 'message' => 'Login successful');
        } else {
            $response = array('status' => 'failure', 'message' => 'Invalid login credentials');
        }

        echo json_encode($response);
    } else {
        $response = array('status' => 'failure', 'message' => 'Missing name or password in the request');
        echo json_encode($response);
    }
} else {
    $response = array('status' => 'failure', 'message' => 'Invalid request method');
    echo json_encode($response);
}
?>