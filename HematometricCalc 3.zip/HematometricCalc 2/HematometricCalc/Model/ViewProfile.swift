//
//  ViewProfile.swift
//  HematometricCalc
//
//  Created by Saranya Ravi on 19/02/24.
//
import Foundation
struct viewprofileRequest : Codable {
    var doctorName : String
    enum CodingKeys: String, CodingKey {
        case doctorName = "name"
    }
}
struct viewprofileResponse : Codable {
    var status : String
    var profileData : profileData
    
}

// MARK: - ProfileData
struct profileData: Codable {
    let doctorName, doctorMobile, doctorGender, doctorDesignation: String
}




    struct EditprofileResponse: Codable {
        let status: String
        let message: String
        
        enum CodingKeys: String, CodingKey {
            case status
            case message
        }
    }


// Assuming your API response also includes profile data fields such as name, mobile, gender, etc.
