import UIKit



class EditprofileVC: UIViewController, UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    @IBOutlet weak var profile: UIImageView!
    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var mobilenumber: UITextField!
    @IBOutlet weak var gender: UITextField!
    @IBOutlet weak var designation: UITextField!
    @IBOutlet weak var photoView: UIView!
    @IBOutlet weak var photoHeight: NSLayoutConstraint!
    @IBOutlet weak var photoWidth: NSLayoutConstraint!
    
    @IBOutlet weak var editBtn: UIButton!
    @IBOutlet weak var editBtnHeight: NSLayoutConstraint!
    @IBOutlet weak var editBtnWidth: NSLayoutConstraint!
    var dname : String?
    var dmobile : String = " "
    var dgender : String = " "
    var ddesignation : String = " "
    let imagePicker = UIImagePickerController()

    
    override func viewDidLoad() {
        super.viewDidLoad()
        photoHeight.constant = photoWidth.constant
        
        //photoView.layer.borderColor = UIColor.red.cgColor
       // photoView.layer.borderWidth = 2.0
        photoView.layer.cornerRadius = photoView.frame.size.width / 2.0
        profile.layer.cornerRadius = profile.frame.size.width / 2.0
        photoView.clipsToBounds = true
        imagePicker.delegate = self
        fetchProfileImage()
        username.text = dname
        mobilenumber.text = dmobile
        gender.text = dgender
        designation.text = ddesignation
        gender.layer.borderColor = UIColor.clear.cgColor
        username.layer.borderColor = UIColor.clear.cgColor
        //dname = UserDefaults.standard.string(forKey: "DocID")
        gender.isUserInteractionEnabled = false
        username.isUserInteractionEnabled = false
         
    }
    @IBAction func onEditImage(_ sender: Any) {
        PresentImagePicker()
        
    }

    @IBAction func saveProfile(_ sender: UIButton) {

        let formData : [String : Any] = [
            "name": username.text ?? "",
            "phno": mobilenumber.text ?? "",
            "gender": gender.text ?? "",
            "designation": designation.text ?? ""
        ]
        
        APIHandler().postAPIValues(type:EditprofileResponse.self, apiUrl: ServiceAPI.editProfile, method: "POST", formData: formData) { response in
            switch response {
            case .success(let result):
                DispatchQueue.main.async {
                    print("Profile update successful: \(result)")
                    let alertController = UIAlertController(title: "Success", message: "Profile details updated succesfully", preferredStyle: .alert)
                    alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
                        self.navigationController?.popViewController(animated: true)
                    }))
                    self.present(alertController, animated: true, completion: nil)
                }
                
            case .failure(let error):
                print("Error updating profile: \(error)")
            }
        }
    }
    
    @IBAction func onback(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    func PresentImagePicker() {
                  let alert = UIAlertController(title: "Choose Media", message: nil, preferredStyle: .actionSheet)
                  alert.addAction(UIAlertAction(title: "Take Photo", style: .default, handler: { _ in
                      self.openCamera() // Call openCamera() from within PresentImagePicker()
                  }))
                  alert.addAction(UIAlertAction(title: "Choose Image", style: .default, handler: { _ in
                      self.openGallery()
                  }))
                  alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
                  present(alert, animated: true, completion: nil)
    }

    func openCamera() {
                  if UIImagePickerController.isSourceTypeAvailable(.camera) {
                      imagePicker.sourceType = .camera
                      present(imagePicker, animated: true, completion: nil)
                  } else {
                      print("Camera not available")
                  }
    }
               
   func openGallery() {
       imagePicker.sourceType = .photoLibrary
       present(imagePicker, animated: true, completion: nil)
   }
               
   func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
       if let image = info[.originalImage] as? UIImage {
           profile.image = image
           uploadProfileWithImage(image: image)
       }
       picker.dismiss(animated: true, completion: nil)
   }
               
   func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
       picker.dismiss(animated: true, completion: nil)
   }
    func uploadProfileWithImage(image: UIImage) {
            let url = URL(string: "http://192.168.32.114/HematometricApp/add_photo.php")!
            let param = ["name":self.dname,
                         "profile_photo":  image] as [String : Any]
        APIHandler.shared.PostUIImageToAPI(apiUrl: url, id: self.dname ?? "", requestBody: param) { result in
                switch result {
                case .success(let res):
                    print("----res",res)
                case .failure(let err):
                    print("-----err",err)
                }
            }
    }
    func fetchProfileImage() {
          LoadingIndicator.shared.showLoading(on: view)
             guard let userID = UserDefaults.standard.string(forKey: "DocID") else {
                 print("User ID not available")
                 return
             }
        let formData : [String : Any ] = ["name": userID]
                 APIHandler.shared.postAPIValues(type: ShowphotoResponse.self, apiUrl: ServiceAPI.profileImage, method: "POST", formData: formData) { result in
                     switch result {
                     case .success(let data):
                         print(data)
                         DispatchQueue.main.async {
                             LoadingIndicator.shared.hideLoading()
                             self.loadImage(url: data.data.profilePhoto, imageView: self.profile)
                         }
                     case .failure(let error):
                        LoadingIndicator.shared.hideLoading()
                         print(error)
                         
                     }
                 }
             }
}


