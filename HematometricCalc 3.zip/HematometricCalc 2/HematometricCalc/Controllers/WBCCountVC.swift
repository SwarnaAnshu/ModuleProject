import UIKit

class WBCCountVC: UIViewController, UITextViewDelegate {
    
    @IBOutlet weak var topView: UIView! {
        didSet {
            topView.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        }
    }
    
    @IBOutlet weak var wbcTxt: UITextView!
    @IBOutlet weak var resultLbl: UILabel!
    @IBOutlet weak var saveBtn: UIButton!
    
    @IBOutlet weak var backbtn: UIButton!
    var wbcTextViewPlaceholder = "Number of WBC in 10 High power field[40*]"
    var patientId = UserDefaultsManager.shared.getPatientId() ?? ""
    var WBCResult = String()
    let saveresult = SaveResult()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.wbcTxt.delegate = self
        wbcTxt.text = wbcTextViewPlaceholder
        wbcTxt.textColor = .lightGray
        saveBtn.isHidden = true
        resultLbl.isHidden = true
        backbtn.setTitle("", for: .normal)
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.text == wbcTextViewPlaceholder {
            textView.text = ""
            textView.textColor = .black
        }
    }
    
    @IBAction func onCalculate(_ sender: Any) {
        guard let wbcText = wbcTxt.text, !wbcText.isEmpty else {
            showAlert(message: "Please enter a value in the WBC field")
            return
        }
        
        calculateWBCCount()
        saveBtn.isHidden = false
        resultLbl.isHidden = false
    }
    
    @IBAction func onSave(_ sender: Any) {
        guard let wbcText = wbcTxt.text, !wbcText.isEmpty else {
            showAlert(message: "Please enter a value in the WBC field")
            return
        }
        
        calculateWBCCount()
        SaveWBCAPI()
    }
    
    func calculateWBCCount() {
        if let text1 = wbcTxt.text,
            let value1 = Double(text1) {
            let Result = (value1 / 10) * 2000
            self.WBCResult = String(format: "%.2f", Result)
            self.resultLbl.text = "\(self.WBCResult)"
        } else {
            print("Invalid input in text fields")
        }
    }
    
    func SaveWBCAPI() {
        let date = DateHelper.getCurrentDateString()
        let parameterrequest = CalculationRequest(currentDate: date, categoryId: 3, subcategoryId: "3.1", result: self.resultLbl.text ?? "")
        saveresult.saveResultAPI(request: parameterrequest, viewcontroller: self) { success in
            if success {
                DispatchQueue.main.async {
                    self.wbcTxt.text = ""
                }
            }
        }
    }
    
    @IBAction func onback(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onHistory(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewResultsVc") as! ViewResultsVc
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}
