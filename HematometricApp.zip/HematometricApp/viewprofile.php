<?php

// Assuming you have already established a database connection

// Retrieving data from request
$conn1 = mysqli_connect("localhost", "root", "", "calci1");
if ($conn1->connect_error) {
    die("Connection failed " . $conn1->connect_error);
}

$response = array();
$name = $_POST['name'];

// Select query to retrieve inserted data excluding the password field
$select_query = "SELECT name, phno, gender, designation FROM docdetails WHERE name = '$name'";
$select_result = mysqli_query($conn1, $select_query);

if ($select_result) {
    $row = mysqli_fetch_assoc($select_result);

    if ($row) {
        // Include retrieved data in the response
        $profileData = array(
            'doctorName' => $row['name'],
            'doctorMobile' => $row['phno'],
            'doctorGender' => $row['gender'],
            'doctorDesignation' => $row['designation'] // Include the 'designation' field
        );

        $viewprofileResponse = array(
            'status' => 'success',
            'profileData' => $profileData
        );

        // Sending response in JSON format
        header('Content-Type: application/json');
        echo json_encode($viewprofileResponse);
    } else {
        $response['status'] = 'failure';
        $response['message'] = 'No data found for the given name';
        echo json_encode($response);
    }
} else {
    $response['status'] = 'failure';
    $response['message'] = 'Error retrieving inserted data: ' . mysqli_error($conn1);
    echo json_encode($response);
}

?>
