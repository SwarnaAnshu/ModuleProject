<?php
$response = array();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the necessary parameters are set
    if (isset($_POST['name']) && isset($_FILES['profile_photo'])) {
        $name = $_POST['name'];
        
        // Concatenate name with ".jpg" extension
        $fileName = $name . ".jpg";
        
        $tempName = $_FILES['profile_photo']['tmp_name'];
        $folder = "uploads/"; // Change the destination folder to your desired folder
        $destination = $folder . $fileName; // Absolute path for the destination file

        // Move the uploaded file to the specified directory
        if (move_uploaded_file($tempName, $destination)) {
            $response['status'] = 'success';
            $response['message'] = 'Image uploaded successfully.';
            $response['file_path'] = $destination; // Provide the file path for further processing
        } else {
            $response['status'] = 'error';
            $response['message'] = 'Failed to move the uploaded file.';
        }
    } else {
        $response['status'] = 'error';
        $response['message'] = 'Invalid request. Required parameters are missing.';
    }
} else {
    $response['status'] = 'error';
    $response['message'] = 'Invalid request method. Only POST method is allowed.';
}

header('Content-Type: application/json');
echo json_encode($response);
?>
