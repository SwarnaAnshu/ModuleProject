<?php
$conn = mysqli_connect("localhost", "root", "", "calci1");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to select data from the categories table
$sql = "SELECT catid, catname FROM categories";

// Execute the query
$result = $conn->query($sql);

// Check if there are any results
if ($result->num_rows > 0) {
    // Create an empty array to store the data
    $data = array();

    // Fetch data and add it to the array
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    // Prepare the response array with status and data
    $response = array(
        "status" => "success",
        "message" => "Categories retrieved successfully",
        "data" => $data
    );

    // Encode the array into JSON format
    $json_data = json_encode($response);

    // Output the JSON data
    echo $json_data;
} else {
    // If no categories found, prepare the response with status and message
    $response = array(
        "status" => "error",
        "message" => "No categories found"
    );

    // Encode the array into JSON format
    $json_data = json_encode($response);

    // Output the JSON data
    echo $json_data;
}

// Close the connection
$conn->close();
?>
