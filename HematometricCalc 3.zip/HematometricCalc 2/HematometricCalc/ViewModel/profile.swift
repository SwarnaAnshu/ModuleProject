//
//  profile.swift
//  HematometricCalc
//
//  Created by SAIL L1 on 02/04/24.
//

import Foundation
struct ShowphotoResponse : Codable {
    let status: String
    let data: DataClass
}

// MARK: - DataClass
struct DataClass: Codable {
    let profilePhoto: String

    enum CodingKeys: String, CodingKey {
        case profilePhoto = "profile_photo"
    }
}

struct Addphoto: Codable {
    let status, message: String
}
