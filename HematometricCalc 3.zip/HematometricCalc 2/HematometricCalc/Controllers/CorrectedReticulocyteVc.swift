import UIKit

class CorrectedReticulocyteVc: UIViewController, UITextViewDelegate {
    
    @IBOutlet weak var topView: UIView! {
        didSet {
            topView.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        }
    }
    
    @IBOutlet weak var reticulocyte1Txt : UITextView!
    @IBOutlet weak var pcvTxt : UITextView!
    @IBOutlet weak var normalPCVTxt : UITextView!
    @IBOutlet weak var result1Lbl : UILabel!
    @IBOutlet weak var reticulocyte2Txt : UITextView!
    @IBOutlet weak var hbTxt : UITextView!
    @IBOutlet weak var normalHbTxt : UITextView!
    @IBOutlet weak var result2Lbl : UILabel!
    @IBOutlet weak var save1Btn: UIButton!
    @IBOutlet weak var save2Btn: UIButton!
    
    
    @IBOutlet weak var backbtn: UIButton!
    var patientId = UserDefaultsManager.shared.getPatientId() ?? ""
    var CorrectedusingPCVResult = String()
    var CorrectedusingHbResult = String()
    var reticulocyte1Placeholder = "Reticulocyte %"
    var pcvPlaceholder = "PCV[%] of patient"
    var normalPCVPlaceholder = "Average Normal PCV[%] for patient"
    var reticulocyte2Placeholder = "Reticulocyte %"
    var hbPlaceholder = "Hb[%] of patient"
    var normalHbPlaceholder = "Average Normal Hb[%] for patient"
    let saveresult = SaveResult()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTextViews()
        hideButtonsAndLabels()
    }
    
    func setupTextViews() {
        reticulocyte1Txt.delegate = self
        pcvTxt.delegate = self
        normalPCVTxt.delegate = self
        reticulocyte2Txt.delegate = self
        hbTxt.delegate = self
        normalHbTxt.delegate = self
        
        reticulocyte1Txt.text = reticulocyte1Placeholder
        pcvTxt.text = pcvPlaceholder
        normalPCVTxt.text = normalPCVPlaceholder
        reticulocyte2Txt.text = reticulocyte2Placeholder
        hbTxt.text = hbPlaceholder
        normalHbTxt.text = normalHbPlaceholder
        
        reticulocyte1Txt.textColor = .lightGray
        pcvTxt.textColor = .lightGray
        normalPCVTxt.textColor = .lightGray
        reticulocyte2Txt.textColor = .lightGray
        hbTxt.textColor = .lightGray
        normalHbTxt.textColor = .lightGray
    }
    
    func hideButtonsAndLabels() {
        save1Btn.isHidden = true
        save2Btn.isHidden = true
        result1Lbl.isHidden = true
        result2Lbl.isHidden = true
        backbtn.setTitle("", for: .normal)
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        textView.text = ""
        textView.textColor = .black
    }

    @IBAction func onCalculateUsingPCV(_ sender: Any) {
        calculateCorrectedReticulocytePCV()
        save1Btn.isHidden = false
        result1Lbl.isHidden = false
    }
    
    @IBAction func onCalculateUsingHb(_ sender: Any) {
        calculateCorrectedReticulocyteHb()
        save2Btn.isHidden = false
        result2Lbl.isHidden = false
    }
    
    @IBAction func onSaveUsingPCV(_ sender: Any) {
        let date = DateHelper.getCurrentDateString()
        let parameterrequest = CalculationRequest(currentDate: date, categoryId: 2, subcategoryId: "2.3", result: self.result1Lbl.text ?? "")
        saveresult.saveResultAPI(request: parameterrequest, viewcontroller: self) { success in
            if success {
                
            }
        }
    }
    
    @IBAction func onSaveUsingHb(_ sender: Any) {
        let date = DateHelper.getCurrentDateString()
        let parameterrequest = CalculationRequest(currentDate: date, categoryId: 2, subcategoryId: "2.4", result: self.result2Lbl.text ?? "")
        saveresult.saveResultAPI(request: parameterrequest, viewcontroller: self) { success in
            if success {
                
            }
        }
    }
    
    @IBAction func onback(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onHistory(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewResultsVc") as! ViewResultsVc
        self.navigationController?.pushViewController(vc, animated: true)
    }

    func calculateCorrectedReticulocytePCV() {
        guard let reticulocyteText = reticulocyte1Txt.text, !reticulocyteText.isEmpty,
              let pcvText = pcvTxt.text, !pcvText.isEmpty,
              let normalPCVText = normalPCVTxt.text, !normalPCVText.isEmpty else {
            showAlert(message: "Please enter values in all fields")
            return
        }
        
        if let value1 = Double(reticulocyteText), let value2 = Double(pcvText), let value3 = Double(normalPCVText) {
            let result = (value1 * value2) / value3
            self.CorrectedusingPCVResult = String(format: "%.2f", result)
            self.result1Lbl.text = "\(self.CorrectedusingPCVResult)"
        } else {
            print("Invalid input in text fields")
        }
    }
    
    func calculateCorrectedReticulocyteHb() {
        guard let reticulocyteText = reticulocyte2Txt.text, !reticulocyteText.isEmpty,
              let hbText = hbTxt.text, !hbText.isEmpty,
              let normalHbText = normalHbTxt.text, !normalHbText.isEmpty else {
            showAlert(message: "Please enter values in all fields")
            return
        }
        
        if let value1 = Double(reticulocyteText), let value2 = Double(hbText), let value3 = Double(normalHbText) {
            let result = (value1 * value2) / value3
            self.CorrectedusingHbResult = String(format: "%.2f", result)
            self.result2Lbl.text = "\(self.CorrectedusingHbResult)"
        } else {
            print("Invalid input in text fields")
        }
    }
    
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}
