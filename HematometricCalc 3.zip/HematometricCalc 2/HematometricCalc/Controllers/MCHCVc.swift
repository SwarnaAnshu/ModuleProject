import UIKit

class MCHCVc: UIViewController, UITextViewDelegate {
    @IBOutlet weak var topView: UIView! {
        didSet {
            topView.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        }
    }

    @IBOutlet weak var hbTxt: UITextField!
    @IBOutlet weak var pcvTxt : UITextView!
    @IBOutlet weak var resultLbl: UILabel!
    
    
    @IBOutlet weak var saveBtn: UIButton!
    var patientId = UserDefaultsManager.shared.getPatientId() ?? ""
    var mchcResult = String()
    let saveresult = SaveResult()
    var pcvPlaceholder = "PCV%"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        saveBtn.isHidden = true
        resultLbl.isHidden = true
        pcvTxt.delegate = self
        pcvTxt.text = pcvPlaceholder
        pcvTxt.textColor = .lightGray
        
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        pcvTxt.text = ""
        pcvTxt.textColor = .black
    }
    
    @IBAction func onCalculate(_ sender: Any) {
        calculateMCHC()
        saveBtn.isHidden = false
        resultLbl.isHidden = false
    }
    
   
    @IBAction func onback(_ sender: Any) {
        SaveMCHCAPI()
    }
    func calculateMCHC() {
        // Check if both text fields have non-empty values
        guard let hbText = hbTxt.text, !hbText.isEmpty,
              let pcvText = pcvTxt.text, !pcvText.isEmpty else {
            // Show alert if any of the text fields are empty
            showAlert(message: "Please enter values in all fields")
            return
        }
        
        // Continue with the calculation
        if let value1 = Double(hbText), let value2 = Double(pcvText) {
            let result = (value1 / value2) * 100
            let mchcResult = String(format: "%.2f g/dL", result) // Append "g/dL" for grams per deciliter
            self.mchcResult = mchcResult
            self.resultLbl.text = mchcResult
            saveBtn.isHidden = false
            resultLbl.isHidden = false
        } else {
            print("Invalid input in text fields")
        }
    }
    
    func SaveMCHCAPI() {
        // Saving MCHC API...
    }
    
    @IBAction func back(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onHistory(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewResultsVc") as! ViewResultsVc
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}
