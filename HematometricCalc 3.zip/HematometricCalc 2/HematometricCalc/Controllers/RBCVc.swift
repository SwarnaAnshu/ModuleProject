//
//  RBCVc.swift
//  HematometricCalc
//
//  Created by SAIL on 31/01/24.
//

import UIKit

class RBCVc: UIViewController {
    @IBOutlet weak var topView: UIView! {
        didSet {
            topView.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    @IBAction func onMCV(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MCVVc") as! MCVVc
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBOutlet weak var backbtn: UIView!
    
    @IBAction func onback(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func onMCH(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MCHVc") as! MCHVc
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func onMCHC(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MCHCVc") as! MCHCVc
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func review(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewResultsVc") as! ViewResultsVc
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
}
