<?php
$conn = mysqli_connect("localhost", "root", "", "calci1");


// Set the response content type to JSON
header('Content-Type: application/json');

// Base URL for constructing full URLs
$baseUrl = "http://172.20.10.8/HematometricApp/"; // Replace with your actual domain and path

// Check for a successful connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize response array
$response = [];

// Check for a valid POST request with 'name' parameter
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['name'])) {
    $name = $_POST['name'];

    // Prepare and execute the SQL query
    $stmt = $conn->prepare("SELECT profile_photo FROM docdetails WHERE name = ?");
    
    // Check for errors in the prepare statement
    if (!$stmt) {
        $response["status"] = "error";
        $response["error"] = "Error in SQL query: " . $conn->error;
    } else {
        $stmt->bind_param("s", $name);
        
        // Execute the statement
        if ($stmt->execute()) {
            $stmt->bind_result($profile_photo);
            
            // Fetch the profile photo
            if ($stmt->fetch()) {
                // Construct full URL for the image
                $fullImageUrl = $baseUrl . $profile_photo;
                
                // Add the full image URL to the response
                $response["status"] = "success";
                $response["data"] = ["profile_photo" => $fullImageUrl];
            } else {
                // No photo found for the given name
                $response["status"] = "error";
                $response["error"] = "No profile photo found for the given name.";
            }
        } else {
            // Error executing the statement
            $response["status"] = "error";
            $response["error"] = "Error executing SQL statement: " . $stmt->error;
        }
    }
} else {
    // Invalid request
    $response["status"] = "error";
    $response["error"] = "Invalid request. Please provide a valid 'name' parameter in a POST request.";
}

// Close the database connection
$conn->close();

// Send the JSON response
echo json_encode($response);
?>
