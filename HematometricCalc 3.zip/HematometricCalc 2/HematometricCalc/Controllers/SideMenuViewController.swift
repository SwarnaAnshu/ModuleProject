//
//  SideMenuViewController.swift
//  HematometricCalc
//
//  Created by Sail L1 on 04/05/24.
//

import UIKit


protocol SideMenu {
    func tap(index:Int)
}

class SideMenuViewController: UIViewController {
    
    
    var delegate:SideMenu!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

  
    @IBAction func closeBtn(_ sender: Any) {
        
        self.dismiss(animated: false, completion: nil)
    }
    
    
    @IBAction func previousHisTap(_ sender: Any) {
        self.delegate.tap(index: 1)
        self.dismiss(animated: false, completion: nil)
    }
    
    
    
    @IBAction func aboutUsTap(_ sender: Any) {
        self.delegate.tap(index: 2)
        self.dismiss(animated: false, completion: nil)
    }
    
    
    
    
    @IBAction func logutTap(_ sender: Any) {
        self.delegate.tap(index: 3)
        self.dismiss(animated: false, completion: nil)
    }
    
    
    
    
    
    
}
