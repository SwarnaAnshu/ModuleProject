<?php

// Assuming you have already established a database connection

// Retrieving data from request
$conn1=mysqli_connect("localhost","root","","calci1");
if($conn1->connect_error){
    die("Connection failed ".$conn->connect_error);
}

$date = $_POST['date']; // Assuming you're receiving date via POST method
$subid = $_POST['subid']; // Assuming you're receiving subid via POST method
$resultval = $_POST['resultval'];
$catid=$_POST['catid'];
// Assuming you're receiving resultval via POST method

// Inserting data into the database
$query = "INSERT INTO result VALUES ('$date', '$subid', '$resultval','$catid')";
$result = mysqli_query($conn1, $query); // Assuming $connection is your database connection object

$response = array();

if ($result) {
    $response['success'] = true;
    $response['message'] = "Data inserted successfully";
} else {
    $response['success'] = false;
    $response['message'] = "Error inserting data: " . mysqli_error($conn1);
}

// Sending response in JSON format
header('Content-Type: application/json');
echo json_encode($response);

?>