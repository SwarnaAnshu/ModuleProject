//
//  historyVc.swift
//  HematometricCalc
//
//  Created by SAIL on 28/02/24.
//

import UIKit

class historyVc: UIViewController {

    @IBOutlet weak var aboutus: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    

    @IBAction func abouthistory(_ sender: Any) {let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "AboutUsVc") as! AboutUsVc
        self.navigationController?.pushViewController(vc, animated: true)
    }


}
