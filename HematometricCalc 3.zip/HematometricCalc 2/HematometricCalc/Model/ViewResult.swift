//
//  ViewResult.swift
//  HematometricCalc
//
//  Created by Saranya Ravi on 20/03/24.
//

import Foundation
struct getCategoryResponse : Codable {
    let status : String
    let message : String
    let data : [Category]
}
struct Category : Codable {
    let catId : String
    let catName : String
    enum CodingKeys: String, CodingKey {
        case catId = "catid"
        case catName = "catname"
    }
}
struct getSubCategoryResponse : Codable {
    let status : String
    let message : String
    let data : [SubCategory]
   
}
struct SubCategory : Codable {
    var subId : String
    var subName : String
    enum CodingKeys : String, CodingKey {
        case subId = "subid"
        case subName = "subname"
    }
}
struct ViewResultRequest : Codable{
    var date : String
    var categoryID : String
    var subcategoryID : String
    init(date: String = "", categoryID: String = "", subcategoryID: String = "") {
        self.date = date
        self.categoryID = categoryID
        self.subcategoryID = subcategoryID
    }
    
}
struct ViewResultResponse : Codable {
    var status : String
    var message : String
    var data : [String]
}
