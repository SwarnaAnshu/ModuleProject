import UIKit

class DoctorLoginVc: UIViewController {
    @IBOutlet weak var topView: UIView!{
        didSet {
            topView.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        }
    }
    @IBOutlet weak var onshow: UIButton!
    @IBOutlet weak var userIdTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    @IBOutlet var forgotBtn: UIButton!
    @IBOutlet weak var forgot: NSLayoutConstraint!
    var isPasswordVisible = false
    
    // Activity indicator
    let activityIndicator = UIActivityIndicatorView(style: .medium)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        forgotBtn.isHidden = false
        navigationController?.setNavigationBarHidden(true, animated: true)
        // Do any additional setup after loading the view.
        
        // Set password text field as secure
        passwordTF.isSecureTextEntry = true
        
        // Configure activity indicator
        activityIndicator.center = view.center
        view.addSubview(activityIndicator)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    @IBAction func loginAction(_ sender: Any) {
        if self.userIdTF.text == "" && self.passwordTF.text == "" {
            AlertManager.showAlert(title: "Field is Empty", message: "Please enter Doctor ID / Password", viewController: self)
        } else {
            // Show activity indicator when login starts
            activityIndicator.startAnimating()
            LoginAPI()
        }
    }
    
    func LoginAPI(){
        let loginReq = loginRequest(doctorName: userIdTF.text ?? "", doctorPassword: passwordTF.text ?? "")
        let formData : [String : Any] = ["name" : loginReq.doctorName, "pass" : loginReq.doctorPassword
        ]
        APIHandler().postAPIValues(type: loginResponse.self, apiUrl: ServiceAPI.doctorLogin, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                DispatchQueue.main.async {
                    // Hide activity indicator when login finishes
                    self.activityIndicator.stopAnimating()
                    
                    if response.status == "success" {
                        UserDefaults.standard.setValue(self.userIdTF.text, forKey: "DocID")
                        UserDefaults.standard.setValue(true, forKey: "isLogin")
                        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MainMenuVc") as! MainMenuVc
                        self.navigationController?.pushViewController(vc, animated: true)
                    }else {
                        // Handle login failure
                    }
                }
            case .failure(let error):
                print("Error : \(error)")
            }
        }
    }
    
    @IBAction func forgotTapped(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "ForgotPasswordVc") as! ForgotPasswordVc
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func togglePasswordVisibility(_ sender: UIButton) {
        isPasswordVisible.toggle()
        passwordTF.isSecureTextEntry = !isPasswordVisible
        let image = isPasswordVisible ? UIImage(systemName: "eye.fill") : UIImage(systemName: "eye.slash.fill")
        onshow.setImage(image, for: .normal)
    }
    @IBAction func onback(_ sender: Any) {self.navigationController?.popViewController(animated: false)
    }
}
