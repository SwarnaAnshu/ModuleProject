<?php
// Assuming you have established a database connection
$conn = mysqli_connect("localhost", "root", "", "calci1");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetching form data
$name = $_POST['name'];
$phno = $_POST['phno'];
$gender = $_POST['gender'];
$designation = $_POST['designation']; // Fetch designation from form data

// Update query for signup table (excluding password)
$sql_signup = "UPDATE signup SET mobilenumber='$phno', designation='$designation', gender='$gender' WHERE name='$name'";

// Update query for docdetails table (excluding password)
$sql_docdetails = "UPDATE docdetails SET phno='$phno', gender='$gender', designation='$designation' WHERE name='$name'";

// Execute queries
if ($conn->query($sql_signup) === TRUE && $conn->query($sql_docdetails) === TRUE) {
    $status_message = "Records updated successfully";
    $status = "success";
} else {
    $status_message = "Error updating records: " . $conn->error;
    $status = "error";
}

$conn->close();

$response = array(
    'status' => $status,
    'message' => $status_message
);

echo json_encode($response);
?>
