//
//  Constant.swift
//  WeatherApp
//
//  Created by MAC-Air on 08/09/23.
//

import Foundation
import UIKit

struct ServiceAPI {
    static let baseURL = "http://172.23.21.7/HematometricApp/"
    
    static let doctorLogin = baseURL+"login.php"
    static let viewprofile = baseURL+"viewprofile.php"
    static let saveResult = baseURL+"result.php"
    static let addprofile = baseURL+"addprofile.php"
    static let signUpUrl = baseURL+"signup.php"
    static let forgetPassoword = baseURL+"forgotpassword.php"
    
    static let getCategory = baseURL + "showcategorie.php"
    
    static let getSubCategory = baseURL + "subcat.php"
    
    static let viewResult = baseURL+"fetch.php"
    static let editProfileImage = baseURL + "add_photo.php"
    static let profileImage = baseURL + "show_photo.php"
    static let editProfile = baseURL + "editprofile.php"
    
    /*static let patientList = baseURL+"patient_list.php"
    static let addPatient = baseURL+"add_patient.php"
    static let patientDetails = baseURL+"patient_details.php?"
    static let saveRbcIndices = baseURL+"add_rbc_indices.php"
    static let saveReticulocyte = baseURL+"add_reticulocyte.php"
    static let saveCorrectedWbc = baseURL+"add_crt_wbc.php"
    static let saveWbc = baseURL+"add_wbc.php"
    static let savePlatelet = baseURL+"add_platelet.php"
     */

    
}
