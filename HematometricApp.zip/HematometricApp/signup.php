<?php
// Establishing a database connection
$conn = mysqli_connect("localhost", "root", "", "calci1");

// Checking the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieving data from request
$name = isset($_POST['name']) ? $_POST['name'] : '';
$phno = isset($_POST['mobilenumber']) ? $_POST['mobilenumber'] : '';
$pass = isset($_POST['password']) ? $_POST['password'] : '';
$confirm_pass = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';
$gender = isset($_POST['gender']) ? $_POST['gender'] : '';
$designation = isset($_POST['designation']) ? $_POST['designation'] : '';

// Validating data
if (empty($name) || empty($phno) || empty($pass) || empty($confirm_pass) || empty($gender) || empty($designation)) {
    $response = array(
        'status' => 'error',
        'message' => 'All fields are required'
    );
} elseif ($pass !== $confirm_pass) {
    $response = array(
        'status' => 'error',
        'message' => 'Passwords do not match'
    );
} else {
    // Check if the record already exists in the signup table
    $check_query = "SELECT * FROM signup WHERE name='$name' AND mobilenumber='$phno'";
    $check_result = mysqli_query($conn, $check_query);
    $num_rows = mysqli_num_rows($check_result);

    if ($num_rows > 0) {
        $response = array(
            'status' => 'error',
            'message' => 'Record with the same name and mobile number already exists. Please choose a different name or mobile number.'
        );
    } else {
        // If record does not exist, insert into the signup table
        $signup_query = "INSERT INTO signup (name, mobilenumber, password, confirm_password, gender, designation) VALUES ('$name', '$phno', '$pass', '$confirm_pass', '$gender', '$designation')";
        $signup_result = mysqli_query($conn, $signup_query);

        // Insert into docdetails table
        $docdetails_query = "INSERT INTO docdetails (name, phno, pass, gender, designation) VALUES ('$name', '$phno', '$pass', '$gender', '$designation')";
        $docdetails_result = mysqli_query($conn, $docdetails_query);

        if ($signup_result && $docdetails_result) {
            $response = array(
                'status' => 'success',
                'message' => 'Data inserted successfully'
            );
        } else {
            $response = array(
                'status' => 'error',
                'message' => 'Error inserting data: ' . mysqli_error($conn)
            );
        }
    }
}

// Sending response in JSON format
header('Content-Type: application/json');
echo json_encode($response);

// Closing the database connection
mysqli_close($conn);
?>
