//
//  SaveModel.swift
//  HematometricCalc
//
//  Created by Haris Madhavan on 10/11/23.
//

import Foundation

// MARK: - SaveData
struct SaveData: Codable {
    var status: Bool?
    var message: String?
}
