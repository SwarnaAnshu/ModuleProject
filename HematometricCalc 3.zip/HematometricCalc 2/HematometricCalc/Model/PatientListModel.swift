//
//  PatientListModel.swift
//  HematometricCalc
//
//  Created by Haris Madhavan on 10/11/23.
//

import Foundation

// MARK: - PatientList
struct PatientList: Codable {
    var status: Bool?
    var message: String?
    var data: [Datum]?
}

// MARK: - Datum
struct Datum: Codable {
    var patientID, name, contactNumber, age: String?
    var gender, height, weight, date: String?
    var mcv, mch, mchc, rc: String?
    var arc, crc1, crc2, rpi: String?
    var correctedWbc, wbc, platelet: String?

    enum CodingKeys: String, CodingKey {
        case patientID = "patient_id"
        case name
        case contactNumber = "contact_number"
        case age, gender, height, weight, date, mcv, mch, mchc, rc, arc, crc1, crc2, rpi
        case correctedWbc = "corrected_wbc"
        case wbc, platelet
    }
}
