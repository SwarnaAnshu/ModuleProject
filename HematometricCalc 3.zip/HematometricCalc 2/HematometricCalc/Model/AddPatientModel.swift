//
//  AddPatientModel.swift
//  HematometricCalc
//
//  Created by Haris Madhavan on 10/11/23.
//

import Foundation

// MARK: - AddPatient
struct AddPatient: Codable {
    var status: Bool?
    var message: String?
}

