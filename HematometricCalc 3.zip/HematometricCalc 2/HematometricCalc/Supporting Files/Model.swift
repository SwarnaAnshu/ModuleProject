//
//  Model.swift
//  HematometricCalc
//
//  Created by SAIL L1 on 04/03/24.
//

import Foundation

struct SignupModel:Codable {
    var status :String
    var message:String
}

struct ForgetPass:Codable {
    var success :Bool
    var message:String
}

