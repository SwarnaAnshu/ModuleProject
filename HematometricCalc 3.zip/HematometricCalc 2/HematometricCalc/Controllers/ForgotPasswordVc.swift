//
//  ForgotPasswordVc.swift
//  HematometricCalc
//
//  Created by SAIL L1 on 31/10/23.
//

import UIKit

class ForgotPasswordVc: UIViewController {
    
    
        
   
  

    @IBOutlet weak var newpasswordTxt : UITextField!
    @IBOutlet weak var confirmnewpasswordTxt : UITextField!
    @IBOutlet weak var newpasswordsubmitBtn : UIButton!
    
    @IBOutlet weak var nameFields: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
     
        // Do any additional setup after loading the view.
    
    }
    
    @IBAction func onback(_ sender: Any) {self.navigationController?.popViewController(animated: true)
    
    }
    
    
    func changePassword() {
                  let formData = ["name":nameFields.text ?? "",
                                  "password":newpasswordTxt.text ?? "",
                                  "confirm_password":confirmnewpasswordTxt.text ?? ""
                  ]
                  
        APIHandler().postAPIValues(type: ForgetPass.self, apiUrl: ServiceAPI.forgetPassoword , method: "POST", formData: formData) { [weak self] result in
                               switch result {
                               case .success(let data):
                                  print(data)
                                  DispatchQueue.main.async {
                                      if data.success == true {
                                          let alert = UIAlertController(title: "Success", message: data.message, preferredStyle: .alert)
                                          let alertaction = UIAlertAction(title: "OK", style: .default) { _ in
                                            
                                              self?.navigationController?.popViewController(animated: false)
                                          }
                                          alert.addAction(alertaction)
                                          self?.present(alert, animated: true, completion: nil)
                                      }else {
                                          
                                          
                                          let alert = UIAlertController(title: "Alert", message: data.message, preferredStyle: .alert)
                                          let alertaction = UIAlertAction(title: "OK", style: .default) { _ in
                                            
                                              self?.navigationController?.popViewController(animated: false)
                                          }
                                          alert.addAction(alertaction)
                                          self?.present(alert, animated: true, completion: nil)
                                          
                                          
                                          
                                      }
                                    
                                      
                                    
                                      }
                                  
                               case .failure(let error):
                                  print(error)
                                  DispatchQueue.main.async {
                                  if let navigation = self?.navigationController  {
//                                      DataManager.shared.sendMessage(title: "Alert", message: "Error", navigation: navigation)
                                  }
                                  }
                               }
                              
                    }

    }
    
    
    
    
    @IBAction func supmitTapped(_ sender: Any) {
       
        
      
    }
    
    @IBAction func onsubmitName(_ sender: Any) {
    
    }
    
    @IBAction func onsubmitPassword(_ sender: Any) {
        if nameFields.text ?? "" != "" && newpasswordTxt.text ?? "" != "" && confirmnewpasswordTxt.text ?? "" != "" {
            changePassword()
        }else {
            
        }
    }
}
