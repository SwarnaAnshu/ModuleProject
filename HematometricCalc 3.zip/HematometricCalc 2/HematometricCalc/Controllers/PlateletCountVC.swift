import UIKit

class PlateletCountVC: UIViewController, UITextViewDelegate {
    
    @IBOutlet weak var topView: UIView! {
        didSet {
            topView.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        }
    }
    
    @IBOutlet weak var plateletTxt: UITextView!
    @IBOutlet weak var resultLbl: UILabel!
    @IBOutlet weak var saveBtn: UIButton!
    
    var plateletTextViewPlaceholder = "Number of Platelet in 10 oil immersion field[100*]"
    var patientId = UserDefaultsManager.shared.getPatientId() ?? ""
    var plateletResult = String()
    let saveresult = SaveResult()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        plateletTxt.delegate = self
        plateletTxt.text = plateletTextViewPlaceholder
        plateletTxt.textColor = .lightGray
        resultLbl.isHidden = true
        saveBtn.isHidden = true
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.text == plateletTextViewPlaceholder {
            textView.text = ""
            textView.textColor = .black
        }
    }
    
    @IBAction func onCalculate(_ sender: Any) {
        guard let plateletText = plateletTxt.text, !plateletText.isEmpty else {
            showAlert(message: "Please enter the platelet count")
            return
        }
        
        calculatePlateletCount()
        saveBtn.isHidden = false
        resultLbl.isHidden = false
    }
    
    @IBAction func oncalculate(_ sender: Any) {
        guard let plateletText = plateletTxt.text, !plateletText.isEmpty else {
            showAlert(message: "Please enter the platelet count")
            return
        }
        
        calculatePlateletCount()
        SavePlateletAPI()
    }
    
    func calculatePlateletCount() {
        if let text1 = plateletTxt.text,
            let value1 = Double(text1) {
            let Result = (value1 / 10) * (20000)
            self.plateletResult = String(format: "%.2f", Result)
            self.resultLbl.text = "\(self.plateletResult)"
        } else {
            print("Invalid input in text fields")
        }
    }
    
    func SavePlateletAPI() {
        let date = DateHelper.getCurrentDateString()
        let parameterrequest = CalculationRequest(currentDate: date, categoryId: 5, subcategoryId: "5.1", result: self.resultLbl.text ?? "")
        saveresult.saveResultAPI(request: parameterrequest, viewcontroller: self) { success in
            if success {
                DispatchQueue.main.async {
                    self.plateletTxt.text = ""
                }
            }
        }
    }
    
    @IBAction func onback(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onHistory(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewResultsVc") as! ViewResultsVc
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}
