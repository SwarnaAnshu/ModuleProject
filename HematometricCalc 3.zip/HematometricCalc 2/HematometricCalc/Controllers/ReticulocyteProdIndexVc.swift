import UIKit

class ReticulocyteProdIndexVc: UIViewController, UITextViewDelegate {
    
    @IBOutlet weak var topView: UIView! {
        didSet {
            topView.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        }
    }
    
    @IBOutlet weak var correctedreticulocyteTxt: UITextView!
    @IBOutlet weak var maturationTimeTxt: UITextView!
    @IBOutlet weak var resultLbl: UILabel!
    @IBOutlet weak var saveBtn: UIButton!
    
    var patientId = UserDefaultsManager.shared.getPatientId() ?? ""
    var CorrectedWBCResult = String()
    let saveresult = SaveResult()
    
    var correctedreticylocytePlaceholder = "Corrected Reticulocyte Count"
    var maturationtimePlaceholder = "Maturation Time in days"
    
    @IBOutlet weak var backbtn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.correctedreticulocyteTxt.delegate = self
        self.maturationTimeTxt.delegate = self
        correctedreticulocyteTxt.text = correctedreticylocytePlaceholder
        maturationTimeTxt.text = maturationtimePlaceholder
        correctedreticulocyteTxt.textColor = .lightGray
        maturationTimeTxt.textColor = .lightGray
        saveBtn.isHidden = true
        resultLbl.isHidden = true
        backbtn.setTitle("", for: .normal)
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView == correctedreticulocyteTxt {
            correctedreticulocyteTxt.text = ""
            correctedreticulocyteTxt.textColor = .black
        } else if textView == maturationTimeTxt {
            maturationTimeTxt.text = ""
            maturationTimeTxt.textColor = .black
        }
    }
    
    @IBAction func onCalculate(_ sender: Any) {
        guard let correctedReticulocyteText = correctedreticulocyteTxt.text, !correctedReticulocyteText.isEmpty,
              let maturationTimeText = maturationTimeTxt.text, !maturationTimeText.isEmpty else {
            showAlert(message: "Please enter values in all fields")
            return
        }
        
        calculateCorrectedWBCCount()
        saveBtn.isHidden = false
        resultLbl.isHidden = false
    }
    
    @IBAction func onback(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onSave(_ sender: Any) {
        saveUsingProdIndex()
    }
    
    func calculateCorrectedWBCCount() {
        if let text1 = correctedreticulocyteTxt.text, let text2 = maturationTimeTxt.text,
            let value1 = Double(text1), let value2 = Double(text2) {
            let Result = (value1 * 100) / (value2 + 100)
            self.CorrectedWBCResult = String(format: "%.2f", Result)
            self.resultLbl.text = "\(self.CorrectedWBCResult)"
        } else {
            print("Invalid input in text fields")
        }
    }
    
    func saveUsingProdIndex() {
        let date = DateHelper.getCurrentDateString()
        let parameterrequest = CalculationRequest(currentDate: date, categoryId: 2, subcategoryId: "2.5", result: self.resultLbl.text ?? "")
        saveresult.saveResultAPI(request: parameterrequest, viewcontroller: self) { success in
            if success {
                DispatchQueue.main.async {
                    self.correctedreticulocyteTxt.text = ""
                    self.maturationTimeTxt.text = ""
                }
            }
        }
    }
    
    @IBAction func onHistory(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewResultsVc") as! ViewResultsVc
        self.navigationController?.pushViewController(vc, animated: true)
    }

    func showAlert(message: String) {
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}
