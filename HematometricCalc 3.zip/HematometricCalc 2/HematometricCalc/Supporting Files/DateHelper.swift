//
//  DateHelper.swift
//  HematometricCalc
//
//  Created by Haris Madhavan on 10/11/23.
//

import Foundation

class DateHelper {
    static func getCurrentDateString() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        return dateFormatter.string(from: Date())
    }
}

