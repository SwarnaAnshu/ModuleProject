//
//  APIHandler.swift
//  WeatherApp
//
//  Created by Haris Madhavan on 07/09/23.
//

import Foundation
import UIKit


class APIHandler {
    static var shared: APIHandler = APIHandler()
    var dynamicId = ""
    init() {}
    
    func getAPIValues<T:Codable>(type: T.Type, apiUrl: String, method: String, onCompletion: @escaping (Result<T, Error>) -> Void) {
                
        guard let url = URL(string: apiUrl) else {
                    let error = NSError(domain: "Invalid URL", code: 0, userInfo: nil)
                    onCompletion(.failure(error))
                    return
                }
                
                var request = URLRequest(url: url)
                request.httpMethod = "GET"
                                
                let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
                    if let error = error {
                        onCompletion(.failure(error))
                        return
                    }
                    
                    guard let data = data else {
                        let error = NSError(domain: "No data received", code: 1, userInfo: nil)
                        onCompletion(.failure(error))
                        return
                    }
                    
                    do {
                        let decodedData = try JSONDecoder().decode(type, from: data)
                        onCompletion(.success(decodedData))
                        print(decodedData)
                    } catch {
                        onCompletion(.failure(error))
                    }
                }
                
                task.resume()
            }
    
    func postAPIValues<T: Codable>(
        type: T.Type,
        apiUrl: String,
        method: String,
        formData: [String: Any], // Dictionary for form data parameters
        onCompletion: @escaping (Result<T, Error>) -> Void) {
        guard let url = URL(string: apiUrl) else {
            let error = NSError(domain: "Invalid URL", code: 0, userInfo: nil)
            onCompletion(.failure(error))
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        // Construct the form data string
        var formDataString = ""
        for (key, value) in formData {
            formDataString += "\(key)=\(value)&"
        }
        formDataString = String(formDataString.dropLast()) // Remove the trailing "&"
        
        // Set the request body
        request.httpBody = formDataString.data(using: .utf8)
        
        // Set the content type to "application/x-www-form-urlencoded"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                onCompletion(.failure(error))
                return
            }
            guard let data = data else {
                let error = NSError(domain: "No data received", code: 1, userInfo: nil)
                onCompletion(.failure(error))
                return
            }
            do {
                let decodedData = try JSONDecoder().decode(type, from: data)
                onCompletion(.success(decodedData))
                print(decodedData)
            } catch {
                onCompletion(.failure(error))
            }
        }
        task.resume()
    }
    
    func postMethod(url: String, formdata:[String:Any], onCompletion: @escaping (Result<String, Error>) -> Void) {
        // Define the URL of the API endpoint
        if let url = URL(string: url) {
            
            // Prepare the URL request object
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            
            // Set the content type to JSON
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            
            // Create the JSON data to send
            let json: [String: Any] = ["username": "user123", "password": "pass123"]
            let jsonData = try? JSONSerialization.data(withJSONObject: json)
            
            // Attach JSON data to the request
            request.httpBody = jsonData
            
            // Create a URLSession data task
            let task = URLSession.shared.dataTask(with: request) { data, response, error in
                // Check for errors
                if let error = error {
                    print("Error: \(error)")
                    return
                }
                
                // Check for valid response (optional)
                if let httpResponse = response as? HTTPURLResponse, !(200...299).contains(httpResponse.statusCode) {
                    print("Server returned an error: \(httpResponse.statusCode)")
                    return
                }
                
                // Process the response data
                if let data = data, let dataString = String(data: data, encoding: .utf8) {
                    print("Response data string:\n \(dataString)")
                }
            }
            
            // Start the data task
            task.resume()
        }

    }
    func PostUIImageToAPI(apiUrl: URL, id: String, requestBody:[String:Any],onCompletion: @escaping (Result< Any, Error>) -> Void){
        let boundary = UUID().uuidString
           dynamicId = id
           // Create the request object
           var request = URLRequest(url: apiUrl)
           request.httpMethod = "POST"
           request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
           // Create the request body using the provided parameters
           let body = createMultipartFormData(parameters: requestBody, boundary: boundary)
      print("------body",String(data: body, encoding: .utf8))
           request.httpBody = body
           // Create URLSessionDataTask for making the request
           let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
               // Check for any errors
               if let error = error {
                   onCompletion(.failure(error))
                   return
               }
               // Check if there's any data returned
               guard let data = data else {
                   onCompletion(.failure(NSError(domain: "com.example", code: -1, userInfo: [NSLocalizedDescriptionKey: "No data returned from POST request"])))
                   return
               }
               if let httpResponse = response as? HTTPURLResponse {
                   print("Status Code: \(httpResponse.statusCode)")
                   print("---",String(data: data, encoding: .utf8))
                   do {
                       // Convert response data to JSON
                       let jsonResponse = try JSONSerialization.jsonObject(with: data, options: [])
                       onCompletion(.success(jsonResponse))
                   } catch {
                       onCompletion(.failure(error))
                   }
               }
           }
           // Resume the task to initiate the request
           task.resume()
    }
    // Function to create multipart form data from dictionary of parameters with UIImage values
    func createMultipartFormData(parameters: [String: Any], boundary: String) -> Data {
        var body = Data()
        
        for (key, value) in parameters {
            if let image = value as? UIImage, let imageData = image.jpegData(compressionQuality: 1.0) {
                body.append("--\(boundary)\r\n".data(using: .utf8)!)
                body.append("Content-Disposition: form-data; name=\"\(key)\"; filename=\"\(dynamicId)-\(key).jpg\"\r\n".data(using: .utf8)!)
                body.append("Content-Type: image/jpeg\r\n\r\n".data(using: .utf8)!)
                body.append(imageData)
                body.append("\r\n".data(using: .utf8)!)
            } else if let stringValue = value as? String {
                body.append("--\(boundary)\r\n".data(using: .utf8)!)
                body.append("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".data(using: .utf8)!)
                body.append(stringValue.data(using: .utf8)!)
                body.append("\r\n".data(using: .utf8)!)
            }
        }
        body.append("--\(boundary)--\r\n".data(using: .utf8)!) // Ending boundary
        return body
    }
}
        
