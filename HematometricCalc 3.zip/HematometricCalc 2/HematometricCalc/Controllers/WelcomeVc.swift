//
//  WelcomeVc.swift
//  HematometricCalc
//
//  Created by SAIL L1 on 31/10/23.
//

import UIKit

class WelcomeVc: UIViewController {
    var isLogin : Bool?
    @IBOutlet weak var topView: UIView!{
        didSet {
            topView.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.isLogin = UserDefaults.standard.bool(forKey: "isLogin")
//        if isLogin == true {
//            let vc = storyboard?.instantiateViewController(withIdentifier: "MainMenuVc") as! MainMenuVc
//            self.navigationController?.pushViewController(vc, animated: true)
//        }else{
//            let vc = storyboard?.instantiateViewController(withIdentifier: "SignUpViewController") as! SignUpViewController
//            self.navigationController?.pushViewController(vc, animated: true)
//        }
    }
    @IBAction func getStartedAction(_ sender: Any) {
        if isLogin == true {
            let vc = storyboard?.instantiateViewController(withIdentifier: "MainMenuVc") as! MainMenuVc
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else {
            let vc = storyboard?.instantiateViewController(withIdentifier: "SignUpViewController") as! SignUpViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}
