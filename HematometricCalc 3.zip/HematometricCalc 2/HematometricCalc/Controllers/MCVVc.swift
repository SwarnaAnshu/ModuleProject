import UIKit

class MCVVc: UIViewController, UITextViewDelegate {
    
    @IBOutlet weak var topView: UIView! {
        didSet {
            topView.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        }
    }
    @IBOutlet weak var pcvTxt: UITextField!
    @IBOutlet weak var rbcTxtView: UITextView!
    @IBOutlet weak var resultLbl: UILabel!
    @IBOutlet weak var backbtn: UIButton!
    @IBOutlet weak var savebtn: UIButton!
    
    var rbcPlaceholder = "RBC Count[millions/cu mm]"
    var patientId = UserDefaultsManager.shared.getPatientId() ?? ""
    var mcvResult = String()
    let saveresult = SaveResult()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        rbcTxtView.delegate = self
        rbcTxtView.text = rbcPlaceholder
        rbcTxtView.textColor = .lightGray
        savebtn.isHidden = true
        resultLbl.isHidden = true
        backbtn.setTitle("", for: .normal)
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        rbcTxtView.text = ""
        rbcTxtView.textColor = .black
    }
    
    @IBAction func onCalculate(_ sender: Any) {
        calculateMCV()
    }

    @IBAction func onSave(_ sender: Any) {
        SaveMCVAPI()
    }
    
    @IBAction func onHistory(_ sender: Any) {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewResultsVc") as! ViewResultsVc
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func back(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func calculateMCV() {
        guard let pcvText = pcvTxt.text, !pcvText.isEmpty,
              let rbcText = rbcTxtView.text, !rbcText.isEmpty else {
            showAlert(message: "Please enter values in all fields")
            return
        }
        
        if let pcvValue = Double(pcvText), let rbcValue = Double(rbcText) {
            let result = (pcvValue / rbcValue) * 10
            let mcvResult = String(format: "%.2f fl", result)
            self.mcvResult = mcvResult
            self.resultLbl.text = mcvResult
            savebtn.isHidden = false
            resultLbl.isHidden = false
        } else {
            showAlert(message: "Invalid input in text fields")
        }
    }
    
    func SaveMCVAPI() {
        let date = DateHelper.getCurrentDateString()
        let parameterrequest = CalculationRequest(currentDate: date, categoryId: 1, subcategoryId: "1.1", result: self.resultLbl.text ?? "")
        saveresult.saveResultAPI(request: parameterrequest, viewcontroller: self) { success in
            if success {
                DispatchQueue.main.sync {
                    self.rbcTxtView.text = self.rbcPlaceholder
                    self.showSaveSuccessAlert()
                }
            } else {
                self.showAlert(message: "Failed to save result")
            }
        }
    }
    
    func showSaveSuccessAlert() {
        let alert = UIAlertController(title: "Success", message: "data inserted successfully", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
            self.navigationController?.popViewController(animated: true)
        }))
        self.present(alert, animated: true, completion: nil)
    }
    
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}
