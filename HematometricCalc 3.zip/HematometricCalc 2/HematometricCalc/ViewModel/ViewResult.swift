//
//  ViewResult.swift
//  HematometricCalc
//
//  Created by Saranya Ravi on 22/03/24.
//

import UIKit

class ViewResult {
    func viewResultAPI(request : ViewResultRequest) {
        let formData : [String: Any] = [
            "date": request.date,
            "catid": request.categoryID,
            "subid": request.subcategoryID,
        ]
        APIHandler().postAPIValues(type: ViewResultResponse.self, apiUrl: ServiceAPI.viewResult, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status ?? "")")
                //print("Message: \(response. ?? "")")
                DispatchQueue.main.async {
                    resultList = response.resultsData
                }
            case .failure(let error):
                print("Error : \(error)")
            }
        }
    }
}
