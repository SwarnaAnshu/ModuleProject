//
//  DoctorLoginModel.swift
//  HematometricCalc
//
//  Created by Haris Madhavan on 13/11/23.
//

import Foundation

// MARK: - DoctorLogin
struct loginResponse : Codable {
    var status: String?
    var message: String?
}

struct loginRequest : Codable {
    var doctorName : String
    var doctorPassword : String
    enum CodingKeys: String, CodingKey {
        case doctorName = "name"
        case doctorPassword = "pass"
    }
}
