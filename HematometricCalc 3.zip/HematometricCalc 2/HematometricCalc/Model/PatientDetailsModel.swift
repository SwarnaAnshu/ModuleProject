//
//  PatientDetailsModel.swift
//  HematometricCalc
//
//  Created by Haris Madhavan on 10/11/23.
//

import Foundation

// MARK: - PatientDetails
struct PatientDetails: Codable {
    var status: Bool?
    var message: String?
    var data: [Details]?
}

// MARK: - Details
struct Details: Codable {
    var patientID, name, contactNumber, age: String?
    var gender, height, weight: String?

    enum CodingKeys: String, CodingKey {
        case patientID = "patient_id"
        case name
        case contactNumber = "contact_number"
        case age, gender, height, weight
    }
}
