//
//  SaveResult.swift
//  HematometricCalc
//
//  Created by Saranya Ravi on 13/02/24.
//

import UIKit
class SaveResult {
    func saveResultAPI(request : CalculationRequest, viewcontroller : UIViewController, completion: @escaping(Bool)->Void) {
        let formData : [String: Any] = [
            "date": request.currentDate,
            "catid": request.categoryId,
            "subid": request.subcategoryId,
            "resultval": request.result
        ]
        APIHandler().postAPIValues(type: CalculationResponse.self, apiUrl: ServiceAPI.saveResult, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status ?? true)")
                print("Message: \(response.message ?? "")")
                completion(true)
                DispatchQueue.main.async {
                    AlertManager.showAlert(title: "Success", message: response.message!, view: viewcontroller)
//                    AlertManager.showAutoPopAlert(title: "Success", message: response.message!, viewController: viewcontroller, navigationController: viewcontroller.navigationController!,duration: 1.0)
                }
            case .failure(let error):
                print("Error : \(error)")
                completion(false)
            }
        }
      
        
    }
}
