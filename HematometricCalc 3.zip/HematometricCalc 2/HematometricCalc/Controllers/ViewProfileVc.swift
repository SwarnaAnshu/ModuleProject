import UIKit

class ViewProfileVc: UIViewController {
    
    @IBOutlet var usernameLbl: UILabel!
    @IBOutlet var mobileLbl: UILabel!
    @IBOutlet var genderLbl: UILabel!
    @IBOutlet weak var designation: UILabel!
    @IBOutlet weak var profilephoto: UIImageView!
    var doctorprofileData: profileData?
    @IBOutlet weak var photoView: UIView!
    @IBOutlet weak var photoHeight: NSLayoutConstraint!
    @IBOutlet weak var photoWidth: NSLayoutConstraint!
    override func viewDidLoad() {
        super.viewDidLoad()
        photoHeight.constant = photoWidth.constant
        
        //photoView.layer.borderColor = UIColor.red.cgColor
       // photoView.layer.borderWidth = 2.0
        photoView.layer.cornerRadius = photoView.frame.size.width / 2.0
        photoView.clipsToBounds = true
        fetchProfileImage()
        getProfileAPI()
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        // Update the corner radius after the frame is laid out
        photoView.layer.cornerRadius = photoView.frame.size.width / 2.0
    }
    override func viewWillAppear(_ animated: Bool) {
        fetchProfileImage()
        getProfileAPI()
    }
    override func viewDidAppear(_ animated: Bool) {
        
        super.viewDidAppear(animated)
        fetchProfileImage()
        getProfileAPI()
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    @IBAction func onLogout(_ sender: Any) {
        UserDefaults.standard.removeObject(forKey: "isLogin")
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DoctorLoginVc") as! DoctorLoginVc
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func onBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func edit(_ sender: Any) {
        //UserDefaults.standard.set(usernameLbl.text, forKey: "editProfileName")
          
          let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
          let vc = storyBoard.instantiateViewController(withIdentifier: "EditprofileVC") as! EditprofileVC
          
          // Pass other data to the EditProfileVC
        vc.dname = usernameLbl.text!
        vc.dgender = genderLbl.text!
        vc.dmobile = mobileLbl.text!
        vc.ddesignation = designation.text!
          self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func getProfileAPI() {
        let viewprofileReq = viewprofileRequest(doctorName: UserDefaults.standard.string(forKey: "DocID") ?? "")
        let formData: [String: Any] = ["name": viewprofileReq.doctorName]
        
        APIHandler().postAPIValues(type: viewprofileResponse.self, apiUrl: ServiceAPI.viewprofile, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                if response.status == "success" {
                    print("Profile data received successfully")
                    DispatchQueue.main.async {
                        self.doctorprofileData = response.profileData
                        self.usernameLbl.text = self.doctorprofileData?.doctorName
                        self.mobileLbl.text = self.doctorprofileData?.doctorMobile
                        self.genderLbl.text = self.doctorprofileData?.doctorGender
                        self.designation.text = self.doctorprofileData?.doctorDesignation
                    }
                } else {
                    print("Failed to retrieve profile data ")
                }
            case .failure(let error):
                print("Error : \(error)")
            }
        }
    }
    func fetchProfileImage() {
        
        LoadingIndicator.shared.showLoading(on: view)
                 guard let userID = UserDefaults.standard.string(forKey: "DocID") else {
                     print("User ID not available")
                     return
                 }
                 
        let formData : [String : Any ] = ["name": userID]
                 
                 APIHandler.shared.postAPIValues(type: ShowphotoResponse.self, apiUrl: ServiceAPI.profileImage, method: "POST", formData: formData) { result in
                     switch result {
                     case .success(let data):
                         print(data)
                         DispatchQueue.main.async {
                             // No need for optional binding as profilePhoto is not option
                             LoadingIndicator.shared.hideLoading()
                             self.loadImage(url: data.data.profilePhoto, imageView: self.profilephoto)
                         }
                         
                     case .failure(let error):
                         LoadingIndicator.shared.hideLoading()
                         print(error)
                         
                     }
                 }
             }
}
