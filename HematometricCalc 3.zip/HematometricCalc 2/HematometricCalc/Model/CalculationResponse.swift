//
//  CalculationResponse.swift
//  HematometricCalc
//
//  Created by Saranya Ravi on 13/02/24.
//

import Foundation
struct CalculationResponse : Codable {
    var status : Bool?
    var message : String?
}
