import UIKit

class ReticulocyteCountVc: UIViewController, UITextViewDelegate {
    @IBOutlet weak var topView: UIView! {
        didSet {
            topView.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        }
    }
    
    @IBOutlet weak var reticulocyteTxt: UITextView!
    @IBOutlet weak var rbcTotalTxt: UITextField!
    @IBOutlet weak var resultLbl: UILabel!
    @IBOutlet weak var saveBtn: UIButton!
    
    @IBOutlet weak var backBtn: UIButton!
    let saveresult = SaveResult()
    var reticulocytePlaceholer = "Number of Reticulocyte counted per 1000 RBCs"
    var patientId = UserDefaultsManager.shared.getPatientId() ?? ""
    var totalReticulocyteResult = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        reticulocyteTxt.delegate = self
        reticulocyteTxt.text = reticulocytePlaceholer
        reticulocyteTxt.textColor = .lightGray
        saveBtn.isHidden = true
        resultLbl.isHidden = true
    }
    override func viewWillAppear(_ animated: Bool) {
        backBtn.isHidden = false
        backBtn.setTitle("", for: .normal)
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        reticulocyteTxt.text = ""
        reticulocyteTxt.textColor = .black
    }
    
    @IBAction func onCalculate(_ sender: Any) {
        calculateReticulocyteCount()
        saveBtn.isHidden = false
        resultLbl.isHidden = false
    }
    
    @IBAction func onSave(_ sender: Any) {
        
        SaveReticulocyteAPI()
    }
    
    func calculateReticulocyteCount() {
        // Check if both text fields have non-empty values
        guard let reticulocyteText = reticulocyteTxt.text, !reticulocyteText.isEmpty,
              let rbcTotalText = rbcTotalTxt.text, !rbcTotalText.isEmpty else {
            // Show alert if any of the text fields are empty
            showAlert(message: "Please enter values in all fields")
            return
        }
        
        // Continue with the calculation
        if let value1 = Double(reticulocyteText), let value2 = Double(rbcTotalText) {
            let result = (value1 / value2) * 100
            self.totalReticulocyteResult = String(format: "%.2f", result)
            self.resultLbl.text = "\(self.totalReticulocyteResult)"
        } else {
            print("Invalid input in text fields")
        }
    }
    
    func SaveReticulocyteAPI() {
        let date = DateHelper.getCurrentDateString()
        let parameterrequest = CalculationRequest(currentDate: date, categoryId: 2, subcategoryId: "2.1", result: self.resultLbl.text ?? "")
        
        
        saveresult.saveResultAPI(request: parameterrequest, viewcontroller: self) { success in
            if success {
                DispatchQueue.main.async {
                    self.reticulocyteTxt.text = ""
                    self.rbcTotalTxt.text = ""
                }
                
            }
        }
    }
    
    @IBAction func onback(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
//    
//    @IBAction func onHistory(_ sender: Any) {
//        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewResultsVc") as! ViewResultsVc
//        self.navigationController?.pushViewController(vc, animated: true)
//    }

    func showAlert(message: String) {
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}

