package com.example.project2;

public class ip {
    static String ipn ="http://172.23.21.7:80/HematometricApp/";
    static String user="" ;
    static String cntct="";
    static String dsg="";
    static String gndr="";
    static String dp="";

}
