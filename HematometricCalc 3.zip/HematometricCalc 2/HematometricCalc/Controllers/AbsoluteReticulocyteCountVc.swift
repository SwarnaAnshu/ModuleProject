import UIKit

class AbsoluteReticulocyteCountVc: UIViewController, UITextViewDelegate {
    
    @IBOutlet weak var reticulocyteTxt: UITextField!
    @IBOutlet weak var redcellTxtView: UITextView!
    @IBOutlet weak var resultLbl: UILabel!
    @IBOutlet weak var saveBtn: UIButton!
    @IBOutlet weak var topView: UIView! {
        didSet {
            topView.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        }
    }
    
    @IBOutlet weak var backBtn: UIButton!
    var redcellPlaceholder = "Red Cell Count[millions/cu mm]"
    var patientId = UserDefaultsManager.shared.getPatientId() ?? ""
    var absoluteReticulocyteResult = String()
    let saveresult = SaveResult()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        redcellTxtView.delegate = self
        redcellTxtView.text = redcellPlaceholder
        redcellTxtView.textColor = .lightGray
        saveBtn.isHidden = true
        resultLbl.isHidden = true
        backBtn.setTitle("", for: .normal)
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        redcellTxtView.text = ""
        redcellTxtView.textColor = .black
    }
    
    @IBAction func onCalculate(_ sender: Any) {
        calculateAbsoluteReticulocyte()
        saveBtn.isHidden = false
        resultLbl.isHidden = false
    }
    
    @IBAction func onSave(_ sender: Any) {
//
        SaveAbsoluteReticulocyteAPI()
    }
    
    func calculateAbsoluteReticulocyte() {
        // Check if both text fields have non-empty values
        guard let reticulocyteText = reticulocyteTxt.text, !reticulocyteText.isEmpty,
              let redcellText = redcellTxtView.text, !redcellText.isEmpty else {
            // Show alert if any of the text fields are empty
            showAlert(message: "Please enter values in all fields")
            return
        }
        
        // Continue with the calculation
        if let value1 = Double(reticulocyteText), let value2 = Double(redcellText) {
            let result = value1 * value2
            self.absoluteReticulocyteResult = String(format: "%.2f", result)
            self.resultLbl.text = absoluteReticulocyteResult
        } else {
            print("Invalid input in text fields")
        }
    }
    
    func SaveAbsoluteReticulocyteAPI() {
        let date = DateHelper.getCurrentDateString()
        let parameterrequest = CalculationRequest(currentDate: date, categoryId: 2, subcategoryId: "2.2", result: self.resultLbl.text ?? "")
        saveresult.saveResultAPI(request: parameterrequest, viewcontroller: self) { success in
            if success {
                DispatchQueue.main.async {
                    self.reticulocyteTxt.text = ""
                    self.redcellTxtView.text = ""
                }
            }
        }
    }
    
    @IBAction func onback(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onHistory(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewResultsVc") as! ViewResultsVc
        self.navigationController?.pushViewController(vc, animated: true)
    }

    func showAlert(message: String) {
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}
