//
//  ReticulocyteVC.swift
//  HematometricCalc
//
//  Created by SAIL on 30/01/24.
//

import UIKit

class ReticulocyteVC: UIViewController {
    @IBOutlet weak var topView: UIView! {
        didSet {
            topView.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func onReticulocyte(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ReticulocyteCountVc") as! ReticulocyteCountVc
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func onAbsolute(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AbsoluteReticulocyteCountVc") as! AbsoluteReticulocyteCountVc
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func onCorrectedReticulocyte(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CorrectedReticulocyteVc") as! CorrectedReticulocyteVc
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func onProductionIndex(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ReticulocyteProdIndexVc") as! ReticulocyteProdIndexVc
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    
    @IBAction func onback(_ sender: Any) {self.navigationController?.popViewController(animated: true)
    }

}
