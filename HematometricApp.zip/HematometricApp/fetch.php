<?php
// Assuming you have established a database connection already
$conn = mysqli_connect("localhost", "root", "", "calci1");

// Check if all required POST parameters are set
if (isset($_POST['date']) && isset($_POST['subid']) && isset($_POST['catid'])) {
    // Sanitize input data
    $date = mysqli_real_escape_string($conn, $_POST['date']);
    $subid = mysqli_real_escape_string($conn, $_POST['subid']);
    $catid = mysqli_real_escape_string($conn, $_POST['catid']);

    // Prepare and execute SQL query
    $query = "SELECT resultval FROM result WHERE date = '$date' AND subid = '$subid' AND catid = '$catid'";
    $result = mysqli_query($conn, $query);

    if ($result) {
        // Check if any row is returned
        if (mysqli_num_rows($result) > 0) {
            $results_array = array();
            // Fetch all results
            while ($row = mysqli_fetch_assoc($result)) {
                $results_array[] = $row['resultval'];
            }
            // Data found, create JSON response
            $response = array('status' => 'success', 'message' => 'Data found', 'data' => $results_array);
            echo json_encode($response);
        } else {
            // No data found, return an empty array
            $response = array('status' => 'success', 'message' => 'No data found for the provided criteria.', 'data' => []);
            echo json_encode($response);
        }
    } else {
        // Query execution failed
        $response = array('status' => 'error', 'message' => 'Query execution failed: ' . mysqli_error($conn), 'data' => null);
        echo json_encode($response);
    }
} else {
    // Missing parameters
    $response = array('status' => 'error', 'message' => 'Missing parameters.', 'data' => null);
    echo json_encode($response);
}
?>
