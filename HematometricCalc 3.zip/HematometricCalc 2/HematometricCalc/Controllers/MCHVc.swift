import UIKit

class MCHVc: UIViewController, UITextViewDelegate {
    @IBOutlet weak var topView: UIView! {
        didSet {
            topView.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        }
    }
    @IBOutlet weak var hbTxt: UITextField!
    @IBOutlet weak var rbcTxtView: UITextView!
    @IBOutlet weak var resultLbl: UILabel!
    @IBOutlet weak var saveBtn: UIButton!
    
    @IBOutlet weak var back: UIButton!
    var rbcPlaceholder = "RBC Count[millions/cu mm]"
    var patientId = UserDefaultsManager.shared.getPatientId() ?? ""
    var mchResult = String()
    let saveresult = SaveResult()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        rbcTxtView.delegate = self
        saveBtn.isHidden = true
        resultLbl.isHidden = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        rbcTxtView.delegate = self
        rbcTxtView.text = rbcPlaceholder
        rbcTxtView.textColor = .lightGray
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        rbcTxtView.text = ""
        rbcTxtView.textColor = .black
    }
    
    @IBAction func onCalculate(_ sender: Any) {
        calculateMCH()
    }
    
    @IBAction func onSave(_ sender: Any) {
        SaveMCHAPI()
    }
    
    func calculateMCH() {
        guard let hbText = hbTxt.text, !hbText.isEmpty,
              let rbcText = rbcTxtView.text, !rbcText.isEmpty else {
            showAlert(message: "Please enter values in all fields")
            return
        }
        
        if let hbValue = Double(hbText), let rbcValue = Double(rbcText) {
            let result = (hbValue / rbcValue) * 10
            let mchResult = String(format: "%.2f pg", result)
            self.mchResult = mchResult
            self.resultLbl.text = mchResult
            saveBtn.isHidden = false
            resultLbl.isHidden = false
        } else {
            showAlert(message: "Invalid input in text fields")
        }
    }
    
    func SaveMCHAPI() {
        let date = DateHelper.getCurrentDateString()
        let parameterrequest = CalculationRequest(currentDate: date, categoryId: 1, subcategoryId: "1.2", result: self.resultLbl.text ?? "")
        saveresult.saveResultAPI(request: parameterrequest, viewcontroller: self) { success in
            if success {
                DispatchQueue.main.sync {
                    self.hbTxt.text = ""
                    self.hbTxt.placeholder = "HB[g/dl]"
                    self.rbcTxtView.text = self.rbcPlaceholder
                    self.rbcTxtView.textColor = .gray
                    
                    // Navigate back to the previous view controller
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
    
    @IBAction func back(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onHistory(_ sender: Any) {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewResultsVc") as! ViewResultsVc
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}
