-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 03, 2024 at 08:09 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `calci1`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `catid` varchar(20) NOT NULL,
  `catname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`catid`, `catname`) VALUES
('1', 'RBC Indices'),
('2', 'Reticulocyte'),
('3', 'WBC Count'),
('4', 'Corrected WBC'),
('5', 'Platlet Count');

-- --------------------------------------------------------

--
-- Table structure for table `docdetails`
--

CREATE TABLE `docdetails` (
  `s.no` int(200) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phno` varchar(255) DEFAULT NULL,
  `pass` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `profile_photo` varchar(200) NOT NULL,
  `designation` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `docdetails`
--

INSERT INTO `docdetails` (`s.no`, `name`, `phno`, `pass`, `gender`, `profile_photo`, `designation`) VALUES
(1, 'apple', '9874563789', '12345', 'fwmale', '', ''),
(2, 'anshu', '12345', '123456', 'female', 'uploads/anshu.jpg', 'doctor'),
(12, 'somu', '1233423', '1234', 'male', '', 'doctor'),
(15, '12', '12', '12', '12', '', '12'),
(16, '34', '34', '34', '34', '', '34'),
(17, 'somu manohar', '12334123', '1234', 'male', '', 'doctor12'),
(19, 'manohar', '1234564', '1234', 'male', 'uploads/manohar.jpg', 'doctor1'),
(20, 'somu manohar1', '123342321', '1234', 'male', '', 'doctor'),
(21, 'manohar', '1234564', NULL, 'male', 'uploads/manohar.jpg', 'doctor1'),
(22, '', NULL, NULL, NULL, 'uploads/profile.jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `forgot_password`
--

CREATE TABLE `forgot_password` (
  `name` varchar(255) NOT NULL,
  `new_password` varchar(255) NOT NULL,
  `confirm_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `forgot_password`
--

INSERT INTO `forgot_password` (`name`, `new_password`, `confirm_password`) VALUES
('anshu', '', '12348'),
('anshu', '', '1232'),
('anshu', '', '1232'),
('anshu', '', '1232'),
('anshu', '', '1232'),
('anshu', '', '1232'),
('anshu', '', '1232'),
('anshu', '', '1232'),
('anshu', '', '1232'),
('anshu', '', '1232'),
('anshu', '', '1232'),
('anshu', '', '1232'),
('anshu', '', '1232'),
('anshu', '', '1232'),
('anshu', '', '1232'),
('anshu', '', '1232'),
('anshu', '', '1232'),
('anshu', '', '1232'),
('anshu', '', '1233'),
('anshu', '', '1233'),
('anshu', '', '1232'),
('anshu', '', '1232'),
('anshu', '', '12340'),
('anshu', '', '12340'),
('anshu', '', '12340'),
('anshu', '', '1232');

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `date` varchar(30) NOT NULL,
  `subid` varchar(30) NOT NULL,
  `resultval` varchar(30) NOT NULL,
  `catid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`date`, `subid`, `resultval`, `catid`) VALUES
('20-10-2024', '1.1', '657', 1),
('15/02/2024', '123', '4566', 5555),
('22/09/2020', '1', '15.8', 1),
('', '', '', 0),
('2024-03-04', '1.1', '164', 1),
('2024-03-05', '1.1', '410.00', 1),
('2024-03-05', '1.2', '780.00', 1),
('2024-03-05', '1.3', '1012.50', 1),
('2024-03-05', '2.1', '952.94', 2),
('2024-03-05', '2.2', '2808.00', 2),
('2024-03-05', '2.4', '1111', 2),
('2024-03-05', '0', '64800.00', 3),
('2024-03-05', '0', '1111', 4),
('2024-03-05', '5.1', '246000.00', 5),
('2024-03-05', '1.1', '0.01', 1),
('2024-03-05', '1.2', '3.54', 1),
('2024-03-05', '1.3', '144.44', 1),
('2024-03-05', '2.1', '13.64', 2),
('2024-03-05', '2.2', '207318709.00', 2),
('2024-03-05', '2.5', '1111', 2),
('2024-03-05', '3.1', '15000.00', 3),
('2024-03-05', '5.1', '150000.00', 5),
('2024-03-05', '1.1', '1.00', 1),
('2024-03-05', '1.2', '10.00', 1),
('2024-03-05', '2.1', '50.00', 2),
('2024-03-06', '1.1', '849.78', 1),
('2024-03-06', '1.2', '0.97', 1),
('2024-03-06', '1.2', '0.97', 1),
('2024-03-06', '1.2', '0.97', 1),
('2024-03-06', '1.3', '25.81', 1),
('2024-03-06', '2.1', '8.38', 2),
('2024-03-06', '2.2', '4288.00', 2),
('2024-03-06', '2.4', '70.52', 2),
('2024-03-06', '2.5', '50.34', 2),
('2024-03-06', '5.1', '914000.00', 5),
('2024-03-06', '5.1', '178000.00', 5),
('2024-03-06', '4.1', '1111', 4),
('2024-03-06', '3.1', '1600.00', 3),
('2024-03-06', '2.1', '100.00', 2),
('2024-03-06', '2.1', '110.26', 2),
('2024-03-06', '2.1', '89.74', 2),
('2024-03-06', '1.1', '10.00', 1),
('2024-03-06', '1.2', '10.00', 1),
('2024-03-06', '1.1', '0.91', 1),
('2024-03-04', '1.1', '164', 1),
('', '', '', 0),
('', '', '', 0),
('', '', '', 0),
('14/03/2024', '3.1', '60.65', 3),
('14/03/2024', '3.1', '60.65', 3),
('14/03/2024', '2.1', '60.65', 2),
('14/03/2024', '3.1', '', 3),
('14/03/2024', '3.1', '', 3),
('2024-03-05', '2.5', '', 2),
('2024-03-05', '2.5', '30.66', 2);

-- --------------------------------------------------------

--
-- Table structure for table `result1`
--

CREATE TABLE `result1` (
  `date` varchar(30) NOT NULL,
  `subid` varchar(30) NOT NULL,
  `resultval` varchar(30) NOT NULL,
  `catid` int(11) NOT NULL,
  `category_name` varchar(30) NOT NULL,
  `subid_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `result1`
--

INSERT INTO `result1` (`date`, `subid`, `resultval`, `catid`, `category_name`, `subid_name`) VALUES
('2024-03-08', '1.1', '164', 1, '', ''),
('2024-03-08', '1.1', '164', 1, 'RBC Indices', 'MCV'),
('2024-03-08', '1.3', '164', 1, 'RBC Indices', 'MCHC'),
('2024-03-08', '1.3', '164.023', 1, 'RBC Indices', 'MCHC'),
('11_3_2024', '1.2', '2.23', 1, 'RBC Indices', 'MCH'),
('11/03/2034', '2.2', '60.65', 2, 'Reticulocyte', 'Absolute Reticulocyte Count'),
('', '', '', 0, '', ''),
('14/03/2024', '3.1', '60.65', 3, '0', 'ghgj'),
('14/03/2024', '3.1', '60.65', 3, '0', 'ghgj'),
('14/03/2024', '3.1', '60.65', 3, '0', 'ghgj'),
('14/03/2024', '3.1', '60.65', 2, '0', 'ghgj'),
('14/03/2024', '3.1', '60.65', 2, '0', '2.1'),
('14/03/2024', '3.1', '60.65', 2, '0', 'dfsh'),
('14/03/2024', '3.1', '60.65', 2, 'Reticulocyte', 'dfsh'),
('14/03/2024', '2.1', '60.65', 2, 'Reticulocyte', 'reticulocyte count'),
('14/03/2024', '', '80.24', 3, 'wbc count', ''),
('14/03/2024', '', '80.24', 3, 'wbc count', '');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `mobilenumber` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `confirm_password` varchar(255) NOT NULL,
  `designation` varchar(20) NOT NULL,
  `gender` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `name`, `mobilenumber`, `password`, `confirm_password`, `designation`, `gender`) VALUES
(1, 'anshu', '12345', '123456', '123456', 'doctor', ''),
(5, 'anshu', '12345', '123456', '123456', 'doctor', ''),
(6, 'naveena', '9876543210', '123', '123', '', ''),
(7, 'somu', '1233423', '1234', '1234', '', 'male'),
(10, '12', '12', '12', '12', '', '12'),
(11, '34', '34', '34', '34', '', '34'),
(12, 'somu manohar', '12334123', '1234', '1234', 'doctor12', 'male'),
(14, 'manohar', '1234564', '1234', '1234', 'doctor1', 'male'),
(15, 'somu manohar1', '123342321', '1234', '1234', 'doctor', 'male');

-- --------------------------------------------------------

--
-- Table structure for table `subcategories`
--

CREATE TABLE `subcategories` (
  `catid` varchar(40) NOT NULL,
  `subid` varchar(40) NOT NULL,
  `subname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subcategories`
--

INSERT INTO `subcategories` (`catid`, `subid`, `subname`) VALUES
('1', '1.1', 'MCV'),
('1', '1.2', 'MCH'),
('1', '1.3', 'MCHC'),
('2', '2.1', 'Reticulocyte Count'),
('2', '2.2', 'Absolute Reticulocyte Count'),
('2', '2.3', 'Corrected Reticulocyte Count using PCV'),
('2', '2.5', 'Reticulocyte Production Index'),
('2', '2.4', 'Corrected Reticulocyte Count using HB');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `docdetails`
--
ALTER TABLE `docdetails`
  ADD PRIMARY KEY (`s.no`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `docdetails`
--
ALTER TABLE `docdetails`
  MODIFY `s.no` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
