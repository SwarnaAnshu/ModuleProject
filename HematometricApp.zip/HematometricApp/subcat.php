<?php
// Database connection
$conn = mysqli_connect("localhost", "root", "", "calci1");

// Check connection
if ($conn->connect_error) {
    // If connection fails, create response array with error status and message
    $response = array(
        "status" => "error",
        "message" => "Connection failed: " . $conn->connect_error
    );
} else {
    // Get the catid from the POST request
    $catid = $_POST['catid']; // Assuming you're passing the catid through a POST request

    // SQL query to select data from the subcategories table based on catid
    $sql = "SELECT subid, subname FROM subcategories WHERE catid = '$catid'";

    // Execute the query
    $result = $conn->query($sql);

    // Check if there are any results
    if ($result->num_rows > 0) {
        // If results found, prepare data array
        $rows = array();
        while($row = $result->fetch_assoc()) {
            $rows[] = $row;
        }

        // Prepare response array with success status, data, and message
        $response = array(
            "status" => "success",
            "message" => "Data retrieved successfully",
            "data" => $rows
        );
    } else {
        // If no results found, prepare response array with failure status, message, and empty data array
        $response = array(
            "status" => "failure",
            "message" => "No subcategories found for the given catid",
            "data" => array()
        );
    }
}

// Convert the response array to JSON format and output it
echo json_encode($response);

// Close the connection
$conn->close();
?>
